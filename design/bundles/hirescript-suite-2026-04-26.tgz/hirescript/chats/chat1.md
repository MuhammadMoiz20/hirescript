# Product Launch

_Started 2026-04-24 18:45 UTC_

---

## User



## Assistant

I'll design HireScript — a document-centric LaTeX resume tool where the PDF is the hero and Claude is a side rail. Let me commit to the aesthetic first, then build.

**Design system commitment:**
- **Type:** Source Serif 4 (headings, where it reads well) + Inter (UI) + JetBrains Mono (LaTeX, diffs, metadata, page counts — mono as design element)
- **Color:** Ink (oklch 0.18 0 0) on Paper (oklch 0.985 0.004 85 — warm off-white). One functional accent: a muted terracotta for destructive/override. Success = green-ink (oklch 0.45 0.08 150), Error = red-ink (oklch 0.48 0.13 25). Dark mode = paper-inverted.
- **No:** gradients, glassmorphism, emoji (using geometric glyphs ✓ ✗ ⋯ ⚠ only), rounded-card-with-accent-border, centered chat.
- **Yes:** mono everywhere data appears, page-count badge as structural UI, diff viewer as hero component, skeleton + shimmer loading.

Let me explore what's here and plan.

_[tool: list_files]_

Empty project. I'll build from scratch with the committed aesthetic. Planning:

_[tool: update_todos]_

Starting with the shell. I'll build a single SPA with hash routing for the 10 screens + kitchen sink, with dark mode and ⌘K command palette.

_[tool: write_file]_

_[tool: write_file]_

Now the core components — PageCountBadge, CompileChip, ModelBadge, ProtectedTermPill, and the shared top chrome / nav.

_[tool: write_file]_

_[tool: snip]_

Now the 10 screens. I'll build them in two files to keep things manageable — screens-a (1-5) and screens-b (6-10 + kitchen sink), plus the main index.html.

_[tool: write_file]_

_[tool: snip]_

_[tool: write_file]_

_[tool: write_file]_

_[tool: write_file]_

_[tool: show_html]_

_[tool: snip]_

_[tool: done]_

_[tool: snip]_

_[tool: fork_verifier_agent]_

**HireScript** — 10 screens + kitchen sink, single SPA at `HireScript.html`.

**Aesthetic:** Source Serif (display) + Inter (UI) + JetBrains Mono (data). Ink on warm paper, one terracotta accent for destructive overrides. Zero gradients, zero glassmorphism.

**Structural moves:**
- Page-count badge is a first-class component with 6 states, used in top chrome, diff header, library rows, version rows, chat compile events, PDF preview
- When `page_count ≠ 1`, the whole app tints — red top-chrome border + inline overflow banner + disabled "Save as final"
- Chat is a collapsible 360px right rail, never centered
- Diff viewer: side-by-side unified LaTeX diff with numbered hotspots linking to PDF regions, protected-term strip that gates accept, full compile metadata in header
- ⌘K command palette, dark mode (paper-inverted, not reskinned), hash router, bottom-right screens dock for quick review

**Navigate via** the "Screens" dock (bottom-right), ⌘K, or hash routes (`#/editor/r_linear` for the overflow state, `#/diff` for the diff viewer, `#/kitchen` for the component library).

## User



## Assistant

_[tool: snip]_

I've read the brief. This is a major expansion — Phase 1 (resume editor, already built) stays untouched, and I add the mass-apply surfaces around it. Per the brief's first-step instruction, I should propose nav + new tokens before designing every surface.

Let me first inventory what's in the existing Phase 1 build so the new surfaces inherit cleanly.

_[tool: list_files]_

_[tool: grep]_

Per the brief's "FIRST STEPS": propose nav + new tokens as a single short doc, wait for approval before designing surfaces. I'll build that as a presentable HTML proposal — not just a markdown blob — so the user can see exactly how the new primitives sit alongside the existing system.

_[tool: write_file]_

_[tool: write_file]_

_[tool: write_file]_

_[tool: snip]_

_[tool: done]_

**Proposal at `Proposal.html`** — nav structure, new tokens, and primitive previews. Awaiting your sign-off before building the 11 surfaces.

Key calls I made that diverge slightly from the brief:

- **Merged Profile + KB + Sources into one "Knowledge" destination** (three tabs). Seven nav items felt heavy for a single-tenant tool; these three share data and you'll move between them.
- **Tier hues:** dream=violet, targeted=blue, wide=green, skip=neutral. Weight descends; skip recedes.
- **Mode toggle:** filled side = active, **font-weight** carries override state so color isn't the only signal.
- **11 status pills** — outline-only with glyph + label, so they stack densely without color collisions.
- **Max-headroom gauge** appears in the top bar, not just the dashboard — you'll glance at it constantly.
- **8 new tokens total**, no new spacing/radii. Light + dark pairs designed deliberately.

Reply `ship it` to proceed, or call out anything you want changed before I build screens.

## User

ship it

## Assistant

_[tool: snip]_

Building the 11 surfaces now. Plan:

_[tool: update_todos]_

Starting with fixtures and the shell. I'll work in named files to keep things shareable:
- `ma-fixtures.jsx` — jobs, applications, profile, KB, history, etc.
- `ma-primitives.jsx` — TierBadge, FitChip, StatusPill, ModeToggle, MaxGauge, Sparkline, etc.
- `ma-shell.jsx` — TopBar, NavRail, page chrome
- `ma-screens-1.jsx` (Dashboard, Inbox, Queue, History)
- `ma-screens-2.jsx` (Knowledge tabs, Tiers, Settings)
- `ma-screens-3.jsx` (Notifications, Live session, Component inventory, Microcopy)
- `ma-app.jsx` — router

_[tool: write_file]_

_[tool: snip]_

Now the primitives.

_[tool: write_file]_

_[tool: snip]_

_[tool: update_todos]_

Now the shell — top bar, nav rail, base CSS, page wrapper.

_[tool: write_file]_

_[tool: snip]_

Now Dashboard, Inbox, Queue, History — screens 1.

_[tool: write_file]_

_[tool: snip]_

_[tool: update_todos]_

Now Knowledge, Tiers, Settings.

_[tool: write_file]_

_[tool: snip]_

_[tool: update_todos]_

Last screens: Notifications drawer, Component inventory, Microcopy. Then router and styles.

_[tool: write_file]_

_[tool: snip]_

Now the app shell wiring + CSS. Let me check what proposal CSS tokens were defined first.

_[tool: grep]_

_[tool: snip]_

_[tool: grep]_

_[tool: read_file]_

_[tool: snip]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: snip]_

_[tool: write_file]_

_[tool: write_file]_

_[tool: snip]_

_[tool: write_file]_

_[tool: snip]_

_[tool: done]_

_[tool: fork_verifier_agent]_

**Mass Apply at `Mass Apply.html`** — all 11 surfaces wired.

Built:
- **Dashboard** — KPI band (applied 14d sparkline, queue, needs-you, max-window gauge), tier-cap bars, mode-mix, needs-you queue + 11-event activity feed
- **Inbox** — single unified table, all 19 jobs, filter chips (status + tier), sortable header, every row clickable
- **Job drawer** — header + status strip (status pill, tier, fit, mode, source), classifier reasoning, 4-stage pipeline trace, artifacts (PDF thumb + sources cited), action toolbar
- **Queue** — 4 lanes (Needs you · B-mode · Applying · Paused) + Live session viewer with pulsing browser frame and step-by-step agent trace, stuck on "Years of relevant CRDT experience"
- **History** — 12 applications, R/C/A sent ticks, tokens·wall, sparkline header
- **Knowledge** — three tabs (Profile / Documents / Sources). Profile has identity, work auth with sponsorship matrix, positions, preferences with dealbreakers + kill list, EEO. Documents has retrievable index + live test-retrieval against "ledger idempotency exactly-once payments" + onboarding gaps. Sources has 6 KB ingestors with errors and 6 job-source families with ToS posture badges
- **Tiers** — drag-handle threshold ribbon + 4 tier cards (Dream/Targeted/Wide/Skip) with model-per-stage breakdown, mode toggle, verifier strictness, daily caps + global override knobs
- **Settings** — workspace, API key (Max-window subscription), model defaults per stage, exports, danger zone
- **Notifications drawer** — grouped New/Earlier with push-delivery toggles
- **⌘K palette** — navigate + actions + jobs (try ⌘K)
- **Component inventory** + **Microcopy reference** for handoff

Navigate via the nav rail, ⌘K, the **Screens** dock (top-right button), or hash routes (`#/queue`, `#/knowledge/sources`, `#/tiers`, `#/components`, `#/microcopy`). Dark mode via the ☽/☼ button.

## User

Verifier agent check completed

## Assistant

_[tool: snip]_

_[tool: str_replace_edit]_

## User

Can you integrate hirescript and mass apply in a way that looks intuitive?

## Assistant

_[tool: snip]_

_[tool: list_files]_

Let me explore HireScript first to understand its structure, then integrate.

_[tool: grep]_

_[tool: read_file]_

[Plan: build a single unified entry HTML that overlays both apps in one shell, sharing the top bar and command palette, with a unified left nav grouped into "Per-job" (HireScript) and "Mass-apply" (Mass Apply) sections. Reuse existing screens via iframes to avoid huge refactor.]

_[tool: snip]_

_[tool: read_file]_

[Plan: Build a unified shell `HireScript Suite.html` with one top bar, one left nav grouped into **Per-job** (Library, Editor, Diff, Tailor, History, JDs, Overflow) and **Mass-apply** (Dashboard, Inbox, Queue, History, Knowledge, Tiers), shared Settings + Command Palette, using iframes to host the existing two apps without refactoring them. The shell intercepts iframe navigation and syncs hashes so deep-links work.]

_[tool: snip]_

I'll build a unified suite shell that hosts both apps via iframes, with one top bar, one nav (grouped per-job vs mass-apply), and shared command palette.

_[tool: write_file]_

_[tool: snip]_

_[tool: list_files]_

Now let me check the existing apps' hash routes so the suite shell can navigate them:

_[tool: grep]_

_[tool: grep]_

Now I'll build the suite shell. I'll write the JSX components and the entry HTML.

_[tool: write_file]_

_[tool: write_file]_

_[tool: snip]_

_[tool: done]_

_[tool: fork_verifier_agent]_

_[tool: snip]_

**Suite shell shipped at `HireScript Suite.html`.**

One top bar, one nav (Per-job → HireScript / Mass-apply → Mass Apply), shared ⌘K palette, dark toggle, and an Overview home page. Both apps mount as iframes the first time they're visited and stay mounted so state persists when you flip between them. Inner hash routes are bridged upward so `#/per-job/diff` and `#/mass-apply/queue` are deep-linkable from the suite URL.

## User

Verifier agent check completed

## Assistant

Good catch. Let me check the token setup and fix both issues:

_[tool: grep]_

_[tool: snip]_

_[tool: str_replace_edit]_

Also propagate theme on iframe load so newly-mounted apps inherit the current theme:

_[tool: str_replace_edit]_

_[tool: snip]_

_[tool: done]_

Dark mode bug fixed — toggle now sets `data-theme` on the suite root and propagates to both iframes via attribute + postMessage, so inner apps switch in lockstep.

