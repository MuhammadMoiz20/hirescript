// Mass-Apply token + nav proposal
// Renders a single-page presentable doc: new tokens, tier system, status pills, nav structure.
// Inherits everything from tokens.css; only adds new primitives.

const { useState } = React;

// ─── New tokens proposed ────────────────────────────────────────────────────
const TIER_TOKENS = [
  { id: "dream",     label: "Dream",     hue: "oklch(0.55 0.16 295)", soft: "oklch(0.95 0.04 295)", darkHue: "oklch(0.78 0.14 295)", darkSoft: "oklch(0.28 0.06 295)", weight: "highest", note: "Deep research + Opus tailor + slow lane" },
  { id: "targeted",  label: "Targeted",  hue: "oklch(0.5 0.13 220)",  soft: "oklch(0.94 0.04 220)", darkHue: "oklch(0.75 0.13 220)", darkSoft: "oklch(0.28 0.07 220)", weight: "high",    note: "Sonnet tailor, B-mode default in slice 2" },
  { id: "wide_net",  label: "Wide net",  hue: "oklch(0.55 0.09 160)", soft: "oklch(0.94 0.04 160)", darkHue: "oklch(0.78 0.1 160)",  darkSoft: "oklch(0.28 0.06 160)", weight: "medium",  note: "Haiku classify, A-mode by default" },
  { id: "skip",      label: "Skip",      hue: "oklch(0.55 0.01 250)", soft: "oklch(0.94 0.005 250)", darkHue: "oklch(0.6 0.01 250)", darkSoft: "oklch(0.26 0.006 250)", weight: "muted",   note: "Persisted but never auto-progressed" },
];

const STATUS_PILLS = [
  { id: "ingested",        label: "Ingested",        glyph: "·", color: "ink-3" },
  { id: "classified",      label: "Classified",      glyph: "◇", color: "ink-2" },
  { id: "queued",          label: "Queued",          glyph: "◆", color: "haiku" },
  { id: "applying",        label: "Applying",        glyph: "▶", color: "sonnet", anim: true },
  { id: "applied",         label: "Applied",         glyph: "✓", color: "ok" },
  { id: "paused",          label: "Paused",          glyph: "‖", color: "warn" },
  { id: "stuck",           label: "Stuck",           glyph: "✕", color: "accent" },
  { id: "needs_attention", label: "Needs attention", glyph: "!", color: "err" },
  { id: "skipped",         label: "Skipped",         glyph: "—", color: "ink-4" },
  { id: "errored",         label: "Errored",         glyph: "✕", color: "err" },
  { id: "snoozed",         label: "Snoozed",         glyph: "z", color: "ink-3" },
];

const FIT_BANDS = [
  { id: "strong",   range: "≥ 80",  label: "Strong",   bg: "ok-soft",   fg: "ok" },
  { id: "moderate", range: "50–79", label: "Moderate", bg: "warn-soft", fg: "warn" },
  { id: "weak",     range: "< 50",  label: "Weak",     bg: "paper-3",   fg: "ink-3" },
];

const NEW_TOKENS = [
  { name: "--tier-dream",    desc: "Highest visual weight. Used for tier badges, dashboard segments, dream-tier card edges." },
  { name: "--tier-targeted", desc: "High weight. Calmer than dream, still distinct." },
  { name: "--tier-wide",     desc: "Medium weight. Reads as the engine's default tier." },
  { name: "--tier-skip",     desc: "Muted neutral. Skipped jobs persist in the data; they fade in the UI." },
  { name: "--mode-a",        desc: "Autonomous mode glyph color. Same hue as --sonnet (already in system) — no new color." },
  { name: "--mode-b",        desc: "Review mode glyph color. Same hue as --haiku — emphasizes 'human-eye' read." },
  { name: "--gauge-track",   desc: "Background ring/bar for Max-window gauge. Reuses --paper-3." },
  { name: "--gauge-fill",    desc: "Foreground arc. Steps from --ok → --warn → --err based on % used." },
  { name: "--live-frame",    desc: "Border accent for live browser viewport while the agent is acting. Pulses --warn-soft." },
];

const NAV_TOP = [
  { id: "dashboard", label: "Dashboard", glyph: "◐",   note: "Engine state at a glance" },
  { id: "inbox",     label: "Inbox",     glyph: "▾",   note: "Firehose of ingested jobs", badge: 47 },
  { id: "queue",     label: "Queue",     glyph: "◆",   note: "Awaiting your attention",  badge: 4, badgeKind: "warn" },
  { id: "history",   label: "History",   glyph: "▤",   note: "Audit trail of submissions" },
  { id: "resumes",   label: "Resumes",   glyph: "▦",   note: "Existing master + variants editor", existing: true },
  { id: "knowledge", label: "Knowledge", glyph: "◢",   note: "Profile + KB + sources" },
  { id: "tiers",     label: "Tiers",     glyph: "◈",   note: "Policy editor" },
  { id: "settings",  label: "Settings",  glyph: "⚙",   note: "Auth, keys, audit" },
];

// ─── Atomic preview components ──────────────────────────────────────────────
function TierBadge({ tier, dot = false }) {
  const t = TIER_TOKENS.find(x => x.id === tier);
  if (!t) return null;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: dot ? 0 : "2px 8px",
      fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.04em",
      color: `var(--tier-${t.id})`,
      background: dot ? "transparent" : `var(--tier-${t.id}-soft)`,
      border: dot ? "none" : `1px solid var(--tier-${t.id})`,
      borderRadius: 2, textTransform: "uppercase",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 6, background: `var(--tier-${t.id})` }} />
      {!dot && t.label}
    </span>
  );
}

function FitChip({ score }) {
  const band = score >= 80 ? "strong" : score >= 50 ? "moderate" : "weak";
  const b = FIT_BANDS.find(x => x.id === band);
  return (
    <span style={{
      display: "inline-flex", alignItems: "baseline", gap: 4,
      padding: "1px 6px",
      fontFamily: "var(--f-mono)", fontSize: 12,
      background: `var(--${b.bg})`,
      color: `var(--${b.fg})`,
      border: `1px solid var(--${b.fg})`,
      borderRadius: 2,
    }}>
      <span style={{ fontWeight: 600 }}>{score}</span>
      <span style={{ fontSize: 9, opacity: 0.7 }}>/100</span>
    </span>
  );
}

function StatusPill({ status }) {
  const s = STATUS_PILLS.find(x => x.id === status);
  if (!s) return null;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "1px 7px 1px 6px",
      fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.02em",
      color: `var(--${s.color})`,
      background: "transparent",
      border: `1px solid var(--${s.color})`,
      borderRadius: 999,
    }}>
      <span style={{ fontSize: 10, lineHeight: 1, animation: s.anim ? "blink 1.2s steps(1) infinite" : "none" }}>{s.glyph}</span>
      {s.label}
    </span>
  );
}

function ModeToggle({ value = "A", overridden = false }) {
  return (
    <span style={{
      display: "inline-flex",
      fontFamily: "var(--f-mono)", fontSize: 11,
      border: "1px solid var(--rule)", borderRadius: 2,
      overflow: "hidden",
    }}>
      <span style={{
        padding: "2px 7px",
        background: value === "A" ? "var(--ink)" : "transparent",
        color: value === "A" ? "var(--paper)" : "var(--ink-3)",
        fontWeight: value === "A" ? (overridden ? 700 : 500) : 400,
        display: "inline-flex", alignItems: "center", gap: 3,
      }}>
        <span style={{ fontSize: 9 }}>⚡</span> A
      </span>
      <span style={{
        padding: "2px 7px",
        background: value === "B" ? "var(--ink)" : "transparent",
        color: value === "B" ? "var(--paper)" : "var(--ink-3)",
        fontWeight: value === "B" ? (overridden ? 700 : 500) : 400,
        display: "inline-flex", alignItems: "center", gap: 3,
      }}>
        <span style={{ fontSize: 9 }}>◉</span> B
      </span>
    </span>
  );
}

// ─── Page sections ──────────────────────────────────────────────────────────
function Section({ eyebrow, title, summary, children }) {
  return (
    <section style={{ borderTop: "1px solid var(--rule)", padding: "32px 0" }}>
      <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 32 }}>
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h2 className="serif" style={{ fontSize: 22, margin: "4px 0 8px", letterSpacing: "-0.01em" }}>{title}</h2>
          {summary && <div style={{ fontSize: 13, color: "var(--ink-3)", lineHeight: 1.5 }}>{summary}</div>}
        </div>
        <div>{children}</div>
      </div>
    </section>
  );
}

function NavRow({ item }) {
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "28px 130px 1fr 80px",
      alignItems: "center", gap: 12,
      padding: "10px 0",
      borderBottom: "1px solid var(--rule)",
      opacity: item.existing ? 0.7 : 1,
    }}>
      <span style={{ fontFamily: "var(--f-mono)", color: "var(--ink-3)", fontSize: 14 }}>{item.glyph}</span>
      <span style={{ fontSize: 14, fontWeight: 500 }}>
        {item.label}
        {item.existing && <span className="mono" style={{ marginLeft: 8, fontSize: 10, color: "var(--ink-4)" }}>[existing]</span>}
      </span>
      <span style={{ fontSize: 13, color: "var(--ink-3)" }}>{item.note}</span>
      <span style={{ display: "flex", justifyContent: "flex-end" }}>
        {item.badge != null && (
          <span className="mono" style={{
            fontSize: 11, padding: "1px 6px",
            border: `1px solid ${item.badgeKind === "warn" ? "var(--warn)" : "var(--rule)"}`,
            color: item.badgeKind === "warn" ? "var(--warn)" : "var(--ink-2)",
            background: item.badgeKind === "warn" ? "var(--warn-soft)" : "var(--paper-2)",
            borderRadius: 2,
          }}>{item.badge}</span>
        )}
      </span>
    </div>
  );
}

function TopBarMock() {
  return (
    <div style={{
      border: "1px solid var(--rule)",
      background: "var(--paper)",
      display: "grid", gridTemplateColumns: "auto 1fr auto auto",
      alignItems: "center", height: 44, padding: "0 16px", gap: 16,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 22, height: 22, background: "var(--ink)", color: "var(--paper)", display: "grid", placeItems: "center", fontFamily: "var(--f-mono)", fontWeight: 700 }}>H</div>
        <span className="serif" style={{ fontSize: 16, letterSpacing: "-0.01em" }}>HireScript</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 14, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-2)" }}>
        <span><span style={{ color: "var(--ok)" }}>12</span>&nbsp;applied</span>
        <span style={{ color: "var(--ink-4)" }}>·</span>
        <span><span style={{ color: "var(--warn)" }}>3</span>&nbsp;in queue</span>
        <span style={{ color: "var(--ink-4)" }}>·</span>
        <span><span style={{ color: "var(--accent)" }}>1</span>&nbsp;stuck</span>
        <span style={{ color: "var(--ink-4)", marginLeft: 8 }}>·</span>
        <span style={{ color: "var(--ink-3)" }}>Max&nbsp;<span style={{ color: "var(--ink)" }}>62%</span>&nbsp;→ resets 4:32p</span>
      </div>
      <button style={{ position: "relative", padding: "4px 8px", border: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 11 }}>
        🔔
        <span style={{
          position: "absolute", top: -4, right: -4, fontSize: 9,
          background: "var(--accent)", color: "white",
          width: 14, height: 14, borderRadius: 14, display: "grid", placeItems: "center",
        }}>3</span>
      </button>
      <button style={{ padding: "4px 8px", border: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 11 }}>◐</button>
    </div>
  );
}

function MaxGauge({ pct = 62 }) {
  const angle = (pct / 100) * 270;
  const color = pct >= 90 ? "var(--err)" : pct >= 75 ? "var(--warn)" : "var(--ok)";
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 12 }}>
      <svg width="60" height="60" viewBox="0 0 60 60">
        <path d="M 12 48 A 24 24 0 1 1 48 48" stroke="var(--paper-3)" strokeWidth="4" fill="none" strokeLinecap="round" />
        <path
          d="M 12 48 A 24 24 0 1 1 48 48"
          stroke={color}
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${(angle / 360) * 113} 113`}
        />
        <text x="30" y="34" textAnchor="middle" fontFamily="var(--f-mono)" fontSize="14" fontWeight="600" fill="var(--ink)">{pct}</text>
      </svg>
      <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", lineHeight: 1.5 }}>
        <div>Max-window</div>
        <div style={{ color: "var(--ink-2)" }}>resets in 1h 47m</div>
      </div>
    </div>
  );
}

// ─── Page ───────────────────────────────────────────────────────────────────
function Proposal() {
  const [theme, setTheme] = useState("light");
  React.useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);

  return (
    <div style={{ maxWidth: 980, margin: "0 auto", padding: "48px 32px 96px" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 40 }}>
        <div>
          <div className="eyebrow">Design proposal · 2026-04-26</div>
          <h1 className="serif" style={{ fontSize: 40, margin: "8px 0 4px", letterSpacing: "-0.02em" }}>Mass-apply — nav & new primitives</h1>
          <div style={{ fontSize: 14, color: "var(--ink-3)" }}>
            Tokens and navigation only. Per the brief's first-steps direction, screens come after you sign off below.
          </div>
        </div>
        <button onClick={() => setTheme(t => t === "light" ? "dark" : "light")}
          style={{ padding: "6px 10px", border: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 11 }}>
          {theme === "light" ? "◐ dark" : "◑ light"}
        </button>
      </header>

      <div style={{
        background: "var(--paper-2)", border: "1px solid var(--rule)", padding: 16,
        fontSize: 13, lineHeight: 1.55, color: "var(--ink-2)",
      }}>
        <strong className="serif" style={{ fontSize: 15 }}>Premise.</strong>
        &nbsp;The Phase 1 system (paper/ink, mono-as-data, page-count as first-class chrome) is doing real work. Mass-apply <em>extends</em> it — it doesn't reset it. New primitives below: tier color system, fit-score chip, mode toggle, status pills, Max-headroom gauge, live-session frame. Everything else (buttons, fields, drawers, diff viewer, CompileChip, ModelBadge, eyebrow) carries over unchanged. The new top-bar counters reuse mono-as-data: numbers in ink, separators in ink-4, no icons.
      </div>

      <Section eyebrow="01" title="Top-level navigation" summary="Eight primary destinations. Resumes is unchanged (existing). Knowledge is the merged home for Profile + KB + Sources — the brief's three sub-screens become tabs inside one nav item, not three nav items, because they share data and the user moves between them.">
        <div style={{ borderTop: "1px solid var(--rule)" }}>
          {NAV_TOP.map(item => <NavRow key={item.id} item={item} />)}
        </div>
        <div style={{ marginTop: 16, fontSize: 12, color: "var(--ink-3)", lineHeight: 1.6 }}>
          <strong style={{ color: "var(--ink-2)" }}>Why merge Profile + KB + Sources.</strong> The brief lists 7 nav slots after splitting them. That's too many for a single-tenant tool. The Profile editor, KB document explorer, and KB-source configuration are all "what I am, what I know, where it comes from" — one destination, three tabs. Tiers and Settings stay separate because they're policy/admin, not identity.
        </div>
      </Section>

      <Section eyebrow="02" title="Top bar" summary="Persistent. Counters use mono numerals against ink-4 separators — no icons, no boxes. Max-window headroom appears inline because it gates the entire engine; users will look there 50× a day.">
        <TopBarMock />
        <div style={{ marginTop: 12, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", lineHeight: 1.7 }}>
          counter format: <span style={{ color: "var(--ink-2)" }}>{`{n} {verb}`}</span> · separator <span style={{ color: "var(--ink-2)" }}>·</span> · n colors by intent (ok/warn/accent) · verbs in ink-2
        </div>
      </Section>

      <Section eyebrow="03" title="Tier color system" summary="Four hues. Dream → violet (rare, weighty). Targeted → blue (the workhorse). Wide-net → green (the engine's calm default). Skip → neutral (recedes). Each maps to a token pair (--tier-X / --tier-X-soft) used identically across badges, row accents, card edges, and dashboard segments.">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {TIER_TOKENS.map(t => (
            <div key={t.id} style={{ border: "1px solid var(--rule)", padding: 14, background: "var(--paper-2)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <span style={{ width: 14, height: 14, background: `var(--tier-${t.id})` }} />
                <span style={{ width: 14, height: 14, background: `var(--tier-${t.id}-soft)`, border: `1px solid var(--tier-${t.id})` }} />
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-3)" }}>--tier-{t.id}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <TierBadge tier={t.id} />
                <span style={{ fontSize: 11, fontFamily: "var(--f-mono)", color: "var(--ink-4)" }}>weight: {t.weight}</span>
              </div>
              <div style={{ fontSize: 12, color: "var(--ink-3)" }}>{t.note}</div>
            </div>
          ))}
        </div>
        <div style={{
          marginTop: 16, padding: 12, fontSize: 12, color: "var(--ink-3)",
          background: "var(--paper-2)", border: "1px dashed var(--rule)",
        }}>
          <strong className="mono" style={{ color: "var(--ink-2)" }}>row-accent usage:</strong> a 2px left border using --tier-X on inbox/queue rows. Skip rows use --tier-skip and drop opacity to 0.7. Dream rows get a subtle --tier-dream-soft tint on hover; other tiers don't.
        </div>
      </Section>

      <Section eyebrow="04" title="Fit-score chip" summary="0–100 numeric. Three bands matching the brief: ≥80 strong (green), 50–79 moderate (warn), <50 weak (neutral). Always paired with score number — color is never alone.">
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
          <FitChip score={92} />
          <FitChip score={71} />
          <FitChip score={42} />
          <span style={{ fontSize: 12, color: "var(--ink-4)", fontFamily: "var(--f-mono)" }}>← strong, moderate, weak</span>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr style={{ color: "var(--ink-3)", textAlign: "left" }}>
              <th style={{ padding: "6px 0", fontFamily: "var(--f-mono)", fontWeight: 400, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>band</th>
              <th style={{ padding: "6px 0", fontFamily: "var(--f-mono)", fontWeight: 400, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>range</th>
              <th style={{ padding: "6px 0", fontFamily: "var(--f-mono)", fontWeight: 400, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>fg / bg</th>
            </tr>
          </thead>
          <tbody>
            {FIT_BANDS.map(b => (
              <tr key={b.id} style={{ borderTop: "1px solid var(--rule)" }}>
                <td style={{ padding: "8px 0" }}>{b.label}</td>
                <td style={{ padding: "8px 0", fontFamily: "var(--f-mono)" }}>{b.range}</td>
                <td style={{ padding: "8px 0", fontFamily: "var(--f-mono)", color: "var(--ink-3)" }}>--{b.fg} / --{b.bg}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section eyebrow="05" title="Mode toggle (A / B)" summary="Per-job, never global. Filled side = active. Bold weight = explicit user override of the tier default. Default-from-tier renders at 500. Explicit override renders at 700. Distinguishable without color (matches accessibility rule: color never alone).">
        <div style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-start" }}>
            <ModeToggle value="A" />
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>tier-default A</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-start" }}>
            <ModeToggle value="A" overridden />
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>user-override A</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-start" }}>
            <ModeToggle value="B" />
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>tier-default B</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-start" }}>
            <ModeToggle value="B" overridden />
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>user-override B</span>
          </div>
        </div>
        <div style={{ marginTop: 14, fontSize: 12, color: "var(--ink-3)" }}>
          Glyphs: <span className="mono" style={{ color: "var(--ink-2)" }}>⚡</span> autonomous, <span className="mono" style={{ color: "var(--ink-2)" }}>◉</span> review (human-eye). Tooltips spell out the words on hover.
        </div>
      </Section>

      <Section eyebrow="06" title="Status pills (11 states)" summary="The brief calls out 11. Each gets a glyph + label so colors can repeat without confusion. Outline-only — these stack densely in inbox rows and would crowd in fills.">
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {STATUS_PILLS.map(s => <StatusPill key={s.id} status={s.id} />)}
        </div>
        <div style={{ marginTop: 14, fontSize: 12, color: "var(--ink-3)", lineHeight: 1.6 }}>
          Hue assignment: progress states (queued/applying) reuse model hues to imply "Claude is doing something". Outcomes (applied/skipped/errored) use functional tokens (ok/ink-4/err). Hold-states (paused/snoozed/stuck) use warn/accent for visual weight.
        </div>
      </Section>

      <Section eyebrow="07" title="Max-window headroom gauge" summary="Used in the top bar (compact) and dashboard (large). 270° arc, paper-3 track, fill steps ok → warn → err at 75% / 90%. Mono numeral inside. No animation; this isn't a hype meter.">
        <div style={{ display: "flex", gap: 32, alignItems: "center" }}>
          <MaxGauge pct={28} />
          <MaxGauge pct={62} />
          <MaxGauge pct={84} />
          <MaxGauge pct={96} />
        </div>
      </Section>

      <Section eyebrow="08" title="New tokens (proposed)" summary="Eight new variables. No new spacing or radii — existing scale is tight enough.">
        <div style={{ border: "1px solid var(--rule)" }}>
          {NEW_TOKENS.map((t, i) => (
            <div key={t.name} style={{
              display: "grid", gridTemplateColumns: "200px 1fr",
              padding: "10px 12px", gap: 16,
              borderTop: i ? "1px solid var(--rule)" : "none",
              fontSize: 13,
            }}>
              <span className="mono" style={{ color: "var(--accent)" }}>{t.name}</span>
              <span style={{ color: "var(--ink-2)" }}>{t.desc}</span>
            </div>
          ))}
        </div>
      </Section>

      <Section eyebrow="09" title="Surfaces in scope (after approval)" summary="Eleven surfaces from the brief. The existing resume editor stays. Each new surface gets desktop + 768 + light + dark + at least one of empty/loading/error.">
        <ol style={{ paddingLeft: 18, fontSize: 13, lineHeight: 1.9, color: "var(--ink-2)" }}>
          <li>Dashboard — counters, Max-headroom gauge, per-tier caps, activity feed, first-run empty state</li>
          <li>Inbox — list + drawer, sticky filter bar, virtualized at 200+ rows</li>
          <li>Queue — review-needed cards with tailored PDF + cover letter + form payload tabs</li>
          <li>History — table + per-row detail with confirmation artifacts and agent trace</li>
          <li>Knowledge — three-tab home: Profile, KB documents, Sources & sync</li>
          <li>Profile editor — structured form with onboarding chat side-rail</li>
          <li>Sources — per-source-family cards (ATS / aggregator / scraping / email / paste / agentic)</li>
          <li>Tiers — policy editor with live preview</li>
          <li>Settings — auth, Voyage key, notifications, kill list, answer cache, audit/privacy</li>
          <li>Notifications & captcha-pause — drawer + push-message specs</li>
          <li>Live browser session viewer — full-screen modal with viewport + agent transcript</li>
        </ol>
      </Section>

      <div style={{ marginTop: 48, padding: 20, border: "1px solid var(--ink)", background: "var(--ink)", color: "var(--paper)" }}>
        <div className="eyebrow" style={{ color: "var(--paper-3)" }}>next step</div>
        <div className="serif" style={{ fontSize: 20, marginTop: 4, marginBottom: 8 }}>Approve nav + tokens, then I build the 11 surfaces.</div>
        <div style={{ fontSize: 13, color: "var(--paper-3)", lineHeight: 1.6 }}>
          Reply with: <span className="mono" style={{ color: "var(--paper)" }}>ship it</span> to proceed as proposed,
          <span className="mono" style={{ color: "var(--paper)" }}> swap X</span> to change a token,
          or <span className="mono" style={{ color: "var(--paper)" }}>merge/split nav</span> to restructure.
          The Phase 1 file remains at <span className="mono" style={{ color: "var(--paper)" }}>HireScript.html</span>; new surfaces will land in <span className="mono" style={{ color: "var(--paper)" }}>HireScript v2.html</span> alongside it.
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Proposal />);
