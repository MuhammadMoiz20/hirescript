// Mass-apply app — router + chrome.

const { useState, useEffect, useMemo } = React;

function parseHash() {
  const h = window.location.hash || "#/dashboard";
  const path = h.replace(/^#/, "");
  return path;
}

function App() {
  const [path, setPath] = useState(parseHash());
  const [navCollapsed, setNavCollapsed] = useState(false);
  const [dark, setDark] = useState(false);
  const [drawerJob, setDrawerJob] = useState(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [dockOpen, setDockOpen] = useState(false);

  useEffect(() => {
    const onHash = () => setPath(parseHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  }, [dark]);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); setCmdOpen(o => !o); }
      if (e.key === "Escape") { setCmdOpen(false); setNotifOpen(false); setDrawerJob(null); setDockOpen(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const navigate = (hash) => { window.location.hash = hash; };

  // Determine current screen
  const seg = path.split("/").filter(Boolean);
  const top = seg[0] || "dashboard";
  const sub = seg[1];

  const currentNav = ["dashboard", "inbox", "queue", "history", "knowledge", "tiers", "settings"].includes(top) ? top : null;

  let screen;
  switch (top) {
    case "dashboard":
      screen = <Dashboard onOpenJob={setDrawerJob} />; break;
    case "inbox":
      screen = <Inbox onOpenJob={setDrawerJob} />; break;
    case "queue":
      screen = <Queue onOpenJob={setDrawerJob} />; break;
    case "history":
      screen = <History onOpenApp={() => {}} />; break;
    case "knowledge":
      screen = <Knowledge initialTab={sub || "profile"} />; break;
    case "tiers":
      screen = <TiersPolicy />; break;
    case "settings":
      screen = <Settings />; break;
    case "components":
      screen = <ComponentInventory />; break;
    case "microcopy":
      screen = <Microcopy />; break;
    default:
      screen = <Dashboard onOpenJob={setDrawerJob} />;
  }

  const unread = window.MA.NOTIFICATIONS.filter(n => !n.read).length;

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "var(--paper)" }}>
      <TopBar
        onCmd={() => setCmdOpen(true)}
        onToggleDark={() => setDark(d => !d)}
        dark={dark}
        unread={unread}
        onOpenNotif={() => setNotifOpen(true)}
        onScreensDock={() => setDockOpen(o => !o)}
      />
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        <NavRail
          current={currentNav}
          collapsed={navCollapsed}
          onToggle={() => setNavCollapsed(c => !c)}
          onNavigate={navigate}
        />
        <main style={{ flex: 1, overflowY: "auto", overflowX: "hidden" }}>
          {screen}
          {/* spacer */}
          <div style={{ height: 80 }} />
        </main>
      </div>

      <JobDrawer jobId={drawerJob} onClose={() => setDrawerJob(null)} />
      <NotifDrawer open={notifOpen} onClose={() => setNotifOpen(false)} />
      <CmdPalette
        open={cmdOpen}
        onClose={() => setCmdOpen(false)}
        onNavigate={navigate}
        onOpenJob={setDrawerJob}
      />
      <ScreensDock
        open={dockOpen}
        current={top === "knowledge" ? `knowledge-${sub || "profile"}` : top}
        onNavigate={(h) => { navigate(h); setDockOpen(false); }}
        onClose={() => setDockOpen(false)}
      />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
