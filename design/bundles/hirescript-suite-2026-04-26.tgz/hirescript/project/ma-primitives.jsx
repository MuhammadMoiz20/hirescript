// HireScript mass-apply — primitives
// TierBadge, FitChip, StatusPill, ModeToggle, MaxGauge, Sparkline, ProviderIcon, CompanyMark, Sources icons.
// Exports to window for cross-script use.

const { useState: useStateMA, useEffect: useEffectMA, useRef: useRefMA, useMemo: useMemoMA } = React;

// ─── Company mark ───────────────────────────────────────────────────────────
function CompanyMark({ company, size = 24 }) {
  const c = window.MA.COMPANIES[company] || { name: company, mark: "?", markBg: "var(--ink-3)" };
  return (
    <span title={c.name} style={{
      width: size, height: size,
      background: c.markBg,
      color: c.markFg || "white",
      display: "inline-grid", placeItems: "center",
      fontFamily: "var(--f-mono)", fontWeight: 600,
      fontSize: Math.round(size * 0.5),
      lineHeight: 1, letterSpacing: 0,
      flexShrink: 0,
      borderRadius: 2,
    }}>{c.mark}</span>
  );
}

// ─── Tier badge ─────────────────────────────────────────────────────────────
function TierBadge({ tier, dot = false, size = "sm" }) {
  const labels = { dream: "Dream", targeted: "Targeted", wide_net: "Wide net", skip: "Skip" };
  const fontSize = size === "lg" ? 12 : 10;
  const padY = size === "lg" ? 3 : 2;
  if (dot) {
    return (
      <span title={labels[tier]} style={{
        display: "inline-flex", alignItems: "center", gap: 4,
      }}>
        <span style={{ width: 6, height: 6, borderRadius: 6, background: `var(--tier-${tier})` }} />
        <span style={{ fontFamily: "var(--f-mono)", fontSize: fontSize, color: `var(--tier-${tier})` }}>{labels[tier]}</span>
      </span>
    );
  }
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: `${padY}px 7px`,
      fontFamily: "var(--f-mono)", fontSize,
      letterSpacing: "0.05em", textTransform: "uppercase",
      color: `var(--tier-${tier})`,
      background: `var(--tier-${tier}-soft)`,
      border: `1px solid var(--tier-${tier})`,
      borderRadius: 2,
    }}>
      <span style={{ width: 5, height: 5, borderRadius: 5, background: `var(--tier-${tier})` }} />
      {labels[tier]}
    </span>
  );
}

// ─── Fit chip ───────────────────────────────────────────────────────────────
function FitChip({ score, size = "sm" }) {
  const band = score >= 80 ? "strong" : score >= 50 ? "moderate" : "weak";
  const map = {
    strong:   { fg: "ok",  bg: "ok-soft" },
    moderate: { fg: "warn", bg: "warn-soft" },
    weak:     { fg: "ink-3", bg: "paper-3" },
  };
  const m = map[band];
  const fs = size === "lg" ? 14 : 11;
  return (
    <span title={`Fit ${score}/100 — ${band}`} style={{
      display: "inline-flex", alignItems: "baseline", gap: 3,
      padding: size === "lg" ? "3px 8px" : "1px 6px",
      fontFamily: "var(--f-mono)", fontSize: fs,
      background: `var(--${m.bg})`,
      color: `var(--${m.fg})`,
      border: `1px solid var(--${m.fg})`,
      borderRadius: 2,
    }}>
      <span style={{ fontWeight: 600 }}>{score}</span>
      <span style={{ fontSize: fs - 3, opacity: 0.7 }}>/100</span>
    </span>
  );
}

// ─── Status pill ────────────────────────────────────────────────────────────
const STATUS_META = {
  ingested:        { label: "Ingested",        glyph: "·", color: "ink-3" },
  classified:      { label: "Classified",      glyph: "◇", color: "ink-2" },
  queued:          { label: "Queued",          glyph: "◆", color: "haiku" },
  applying:        { label: "Applying",        glyph: "▶", color: "sonnet", anim: true },
  applied:         { label: "Applied",         glyph: "✓", color: "ok" },
  paused:          { label: "Paused",          glyph: "‖", color: "warn" },
  stuck:           { label: "Stuck",           glyph: "✕", color: "accent" },
  needs_attention: { label: "Needs attention", glyph: "!", color: "err" },
  skipped:         { label: "Skipped",         glyph: "—", color: "ink-4" },
  errored:         { label: "Errored",         glyph: "✕", color: "err" },
  snoozed:         { label: "Snoozed",         glyph: "z", color: "ink-3" },
};

function StatusPill({ status, size = "sm" }) {
  const s = STATUS_META[status];
  if (!s) return null;
  const fs = size === "lg" ? 12 : 10;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: size === "lg" ? "2px 8px" : "1px 7px 1px 6px",
      fontFamily: "var(--f-mono)", fontSize: fs, letterSpacing: "0.02em",
      color: `var(--${s.color})`,
      background: "transparent",
      border: `1px solid var(--${s.color})`,
      borderRadius: 999,
      whiteSpace: "nowrap",
    }}>
      <span style={{ fontSize: fs - 1, lineHeight: 1, animation: s.anim ? "blink 1.2s steps(1) infinite" : "none" }}>{s.glyph}</span>
      {s.label}
    </span>
  );
}

// ─── Mode toggle ────────────────────────────────────────────────────────────
function ModeToggle({ value = "A", overridden = false, onChange, size = "sm", interactive = true }) {
  const fs = size === "lg" ? 12 : 10;
  const padY = size === "lg" ? 3 : 2;
  const padX = size === "lg" ? 9 : 7;
  const Side = ({ side, glyph, label }) => {
    const active = value === side;
    return (
      <span
        onClick={interactive ? () => onChange?.(side) : undefined}
        style={{
          padding: `${padY}px ${padX}px`,
          background: active ? "var(--ink)" : "transparent",
          color: active ? "var(--paper)" : "var(--ink-3)",
          fontWeight: active ? (overridden ? 700 : 500) : 400,
          display: "inline-flex", alignItems: "center", gap: 3,
          cursor: interactive ? "pointer" : "default",
          userSelect: "none",
        }}>
        <span style={{ fontSize: fs - 1 }}>{glyph}</span> {label}
      </span>
    );
  };
  return (
    <span title={`Mode ${value}${overridden ? " (override)" : " (tier default)"}`} style={{
      display: "inline-flex",
      fontFamily: "var(--f-mono)", fontSize: fs,
      border: "1px solid var(--rule)", borderRadius: 2,
      overflow: "hidden",
    }}>
      <Side side="A" glyph="⚡" label="A" />
      <Side side="B" glyph="◉" label="B" />
    </span>
  );
}

// ─── Max-window gauge ───────────────────────────────────────────────────────
function MaxGauge({ pct = 62, size = 60, showLabel = true }) {
  const angle = (pct / 100) * 270;
  const color = pct >= 90 ? "var(--err)" : pct >= 75 ? "var(--warn)" : "var(--ok)";
  const r = size / 2 - 6;
  const cx = size / 2, cy = size / 2;
  // Arc 270°, starts bottom-left, sweeps right around top
  const startA = 135 * Math.PI / 180;
  const endA = startA + 270 * Math.PI / 180;
  const x1 = cx + r * Math.cos(startA), y1 = cy + r * Math.sin(startA);
  const x2 = cx + r * Math.cos(endA), y2 = cy + r * Math.sin(endA);
  const arcLen = 2 * Math.PI * r * 0.75;
  const filled = (angle / 270) * arcLen;
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 12 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <path d={`M ${x1} ${y1} A ${r} ${r} 0 1 1 ${x2} ${y2}`}
          stroke="var(--paper-3)" strokeWidth="4" fill="none" strokeLinecap="round" />
        <path d={`M ${x1} ${y1} A ${r} ${r} 0 1 1 ${x2} ${y2}`}
          stroke={color} strokeWidth="4" fill="none" strokeLinecap="round"
          strokeDasharray={`${filled} ${arcLen}`} />
        <text x={cx} y={cy + 5} textAnchor="middle" fontFamily="var(--f-mono)"
          fontSize={Math.round(size * 0.27)} fontWeight="600" fill="var(--ink)">{pct}</text>
      </svg>
      {showLabel && (
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", lineHeight: 1.5 }}>
          <div>Max-window</div>
          <div style={{ color: "var(--ink-2)" }}>resets in 1h 47m</div>
        </div>
      )}
    </div>
  );
}

// ─── Capacity bar (per-tier daily caps) ─────────────────────────────────────
function CapBar({ used, cap, tier, label }) {
  const pct = cap > 0 ? Math.min(100, (used / cap) * 100) : 0;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "var(--f-mono)", fontSize: 11 }}>
        <span style={{ color: "var(--ink-2)", display: "inline-flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 6, background: `var(--tier-${tier})` }} />
          {label}
        </span>
        <span style={{ color: "var(--ink-3)" }}>
          <span style={{ color: "var(--ink)" }}>{used}</span>
          <span style={{ color: "var(--ink-4)" }}>/{cap}</span>
        </span>
      </div>
      <div style={{ height: 4, background: "var(--paper-3)", position: "relative" }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${pct}%`, background: `var(--tier-${tier})` }} />
      </div>
    </div>
  );
}

// ─── Sparkline ──────────────────────────────────────────────────────────────
function Sparkline({ values, w = 120, h = 28, stroke = "var(--ink-2)", fill = false }) {
  if (!values?.length) return null;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const span = max - min || 1;
  const points = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / span) * (h - 4) - 2;
    return [x, y];
  });
  const path = "M " + points.map(p => p.join(",")).join(" L ");
  return (
    <svg width={w} height={h}>
      {fill && <path d={`${path} L ${w},${h} L 0,${h} Z`} fill="var(--paper-3)" />}
      <path d={path} stroke={stroke} strokeWidth="1.5" fill="none" />
      <circle cx={points.at(-1)[0]} cy={points.at(-1)[1]} r="2" fill={stroke} />
    </svg>
  );
}

// ─── Source / provider icons (text-mark; no SVG illustration) ──────────────
const SOURCE_LABEL = {
  greenhouse: "Greenhouse", lever: "Lever", ashby: "Ashby", workable: "Workable",
  url_paste: "URL paste", email: "Email", agentic: "Agentic", linkedin: "LinkedIn",
  indeed: "Indeed", wellfound: "Wellfound",
};
const SOURCE_GLYPH = {
  greenhouse: "G", lever: "L", ashby: "A", workable: "W",
  url_paste: "↦", email: "@", agentic: "✦", linkedin: "in", indeed: "I", wellfound: "W",
};
function SourceTag({ source }) {
  return (
    <span title={`Source · ${SOURCE_LABEL[source] || source}`} style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-3)",
    }}>
      <span style={{
        width: 14, height: 14,
        background: "var(--paper-3)", border: "1px solid var(--rule)",
        display: "inline-grid", placeItems: "center",
        fontSize: 9, lineHeight: 1, color: "var(--ink-2)",
      }}>{SOURCE_GLYPH[source] || "·"}</span>
      <span>{SOURCE_LABEL[source] || source}</span>
    </span>
  );
}

// ─── Model badge (carry-over from Phase 1, redefined here for completeness) ─
function ModelBadge({ model, size = "sm" }) {
  const labels = { haiku: "Haiku", sonnet: "Sonnet", opus: "Opus" };
  const fs = size === "lg" ? 11 : 10;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      fontFamily: "var(--f-mono)", fontSize: fs,
      color: `var(--${model})`,
      padding: "1px 6px",
      border: `1px solid var(--${model})`,
      borderRadius: 2,
      background: "transparent",
    }}>
      <span style={{ width: 5, height: 5, borderRadius: 5, background: `var(--${model})` }} />
      {labels[model] || model}
    </span>
  );
}

// ─── ToS posture ────────────────────────────────────────────────────────────
function TosPosture({ posture, note }) {
  const map = {
    clean: { label: "Clean", color: "ok",     glyph: "✓" },
    grey:  { label: "Grey area", color: "warn", glyph: "~" },
    red:   { label: "Against ToS", color: "err",  glyph: "!" },
  };
  const m = map[posture] || map.clean;
  return (
    <span title={note} style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      fontFamily: "var(--f-mono)", fontSize: 10,
      padding: "1px 6px",
      border: `1px solid var(--${m.color})`,
      color: `var(--${m.color})`,
      borderRadius: 2,
      letterSpacing: "0.04em", textTransform: "uppercase",
    }}>
      <span style={{ fontSize: 9 }}>{m.glyph}</span>
      ToS: {m.label}
    </span>
  );
}

// ─── Skeleton block (for loading states) ────────────────────────────────────
function Skeleton({ w = "100%", h = 12, style: s }) {
  return (
    <div style={{
      width: w, height: h,
      background: "linear-gradient(90deg, var(--paper-3) 0%, var(--paper-2) 50%, var(--paper-3) 100%)",
      backgroundSize: "200% 100%",
      animation: "skeleton 1.6s linear infinite",
      borderRadius: 1,
      ...s,
    }} />
  );
}

// ─── Page-count badge (carried from Phase 1) ────────────────────────────────
function PageCountBadge({ count, size = "sm" }) {
  const ok = count === 1;
  const fs = size === "lg" ? 11 : 10;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      fontFamily: "var(--f-mono)", fontSize: fs,
      color: ok ? "var(--ok)" : "var(--err)",
      padding: "1px 6px",
      border: `1px solid ${ok ? "var(--ok)" : "var(--err)"}`,
      borderRadius: 2,
    }}>
      <span>{ok ? "✓" : "✗"}</span>
      {count} pg
    </span>
  );
}

// ─── KbdHint (small key) ────────────────────────────────────────────────────
function Kbd({ children }) {
  return (
    <span style={{
      fontFamily: "var(--f-mono)", fontSize: 10,
      padding: "1px 5px",
      background: "var(--paper-3)", border: "1px solid var(--rule)",
      color: "var(--ink-2)",
      borderRadius: 2,
    }}>{children}</span>
  );
}

// ─── Eyebrow ────────────────────────────────────────────────────────────────
function Eyebrow({ children, color = "ink-3" }) {
  return <div className="eyebrow" style={{ color: `var(--${color})` }}>{children}</div>;
}

// ─── Hairline divider ───────────────────────────────────────────────────────
function Hr({ vertical = false, style: s }) {
  return <div style={{
    background: "var(--rule)",
    width: vertical ? 1 : "100%",
    height: vertical ? "100%" : 1,
    flexShrink: 0,
    ...s,
  }} />;
}

// ─── Skeleton @keyframes injected via style tag ─────────────────────────────
if (typeof document !== "undefined" && !document.getElementById("ma-keyframes")) {
  const s = document.createElement("style");
  s.id = "ma-keyframes";
  s.textContent = `
    @keyframes skeleton { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
    @keyframes pulse-frame { 0%, 100% { box-shadow: 0 0 0 1px var(--live-frame), 0 0 0 4px var(--live-frame-soft); } 50% { box-shadow: 0 0 0 1px var(--live-frame), 0 0 0 8px var(--live-frame-soft); } }
    @keyframes dot-bounce { 0%, 80%, 100% { transform: translateY(0); opacity: 0.5; } 40% { transform: translateY(-3px); opacity: 1; } }
    @keyframes spin-slow { 100% { transform: rotate(360deg); } }
  `;
  document.head.appendChild(s);
}

// ─── PdfThumb (simulated) ───────────────────────────────────────────────────
function PdfThumb({ name = "Resume", w = 240, h = 312, pageCount = 1, scanning = false }) {
  return (
    <div style={{ position: "relative", width: w, height: h, background: "var(--paper-2)", border: "1px solid var(--rule)", overflow: "hidden" }}>
      <div style={{ padding: 14, fontSize: 6, lineHeight: 1.5, color: "var(--ink-3)", fontFamily: "var(--f-serif)" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--ink)", textAlign: "center", marginBottom: 2 }}>Moiz Khan</div>
        <div style={{ textAlign: "center", color: "var(--ink-3)", fontSize: 5, marginBottom: 6 }}>
          San Francisco · moiz@khan.dev · github.com/moiz
        </div>
        <div style={{ borderBottom: "1px solid var(--ink-3)", marginBottom: 3 }}>EXPERIENCE</div>
        <div style={{ fontWeight: 600, color: "var(--ink-2)" }}>NVIDIA — Senior Software Engineer</div>
        <div style={{ fontStyle: "italic", color: "var(--ink-4)" }}>Aug 2022 – Present · Santa Clara, CA</div>
        <div>· Lead on quantization runtime for Llama-class models, owning CUDA kernel perf</div>
        <div>· Cut p99 inference latency from 140ms to 38ms via batched FlashAttention rewrite</div>
        <div>· Mentored 4 engineers through promotion; rewrote onboarding runbook</div>
        <div style={{ marginTop: 4, fontWeight: 600, color: "var(--ink-2)" }}>Stripe — SE, Payments Infra</div>
        <div style={{ fontStyle: "italic", color: "var(--ink-4)" }}>Jun 2019 – Jul 2022 · San Francisco, CA</div>
        <div>· Owned ledger settlement perf; reduced p99 from 3.2s to 410ms</div>
        <div>· Rewrote idempotency layer; eliminated double-charge incidents class</div>
        <div>· Drove SOC2 audit evidence collection for payments perimeter</div>
        <div style={{ marginTop: 4, fontWeight: 600, color: "var(--ink-2)" }}>Two Sigma — SE, Trading Infra</div>
        <div style={{ fontStyle: "italic", color: "var(--ink-4)" }}>Jul 2017 – May 2019 · New York</div>
        <div>· Real-time risk pipeline; brought tail latency from 30ms to 8ms</div>
        <div style={{ marginTop: 6, borderBottom: "1px solid var(--ink-3)", marginBottom: 3 }}>EDUCATION</div>
        <div>Carnegie Mellon University — B.S. Computer Science · 2013–2017</div>
        <div style={{ marginTop: 4, borderBottom: "1px solid var(--ink-3)", marginBottom: 3 }}>SKILLS</div>
        <div>CUDA · Rust · Go · Python · Postgres · Kafka · Kubernetes · Terraform</div>
      </div>
      <div style={{ position: "absolute", bottom: 6, right: 8 }}>
        <PageCountBadge count={pageCount} />
      </div>
      {scanning && <div className="scan-shimmer" style={{ position: "absolute", inset: 0 }} />}
    </div>
  );
}

// ─── Spinner (small mono) ──────────────────────────────────────────────────
function Spinner({ size = 12 }) {
  return (
    <span style={{
      display: "inline-block", width: size, height: size,
      border: `1.5px solid var(--rule)`,
      borderTopColor: "var(--ink-2)",
      borderRadius: size,
      animation: "spin-slow 0.9s linear infinite",
    }} />
  );
}

// ─── Empty state ────────────────────────────────────────────────────────────
function EmptyState({ glyph, title, body, cta, ctaOnClick }) {
  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      padding: "64px 32px", textAlign: "center", color: "var(--ink-3)",
    }}>
      <div style={{ fontFamily: "var(--f-mono)", fontSize: 28, color: "var(--ink-3)", marginBottom: 16 }}>{glyph}</div>
      <div className="serif" style={{ fontSize: 20, color: "var(--ink)", marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 13, maxWidth: 380, lineHeight: 1.5, marginBottom: cta ? 16 : 0 }}>{body}</div>
      {cta && (
        <button onClick={ctaOnClick} style={{
          padding: "8px 14px", border: "1px solid var(--ink)",
          background: "var(--ink)", color: "var(--paper)",
          fontFamily: "var(--f-mono)", fontSize: 12,
        }}>{cta}</button>
      )}
    </div>
  );
}

// ─── Tab strip ──────────────────────────────────────────────────────────────
function Tabs({ tabs, value, onChange }) {
  return (
    <div style={{ display: "flex", borderBottom: "1px solid var(--rule)" }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => onChange(t.id)} style={{
          padding: "10px 16px",
          fontFamily: "var(--f-sans)", fontSize: 13,
          color: value === t.id ? "var(--ink)" : "var(--ink-3)",
          fontWeight: value === t.id ? 600 : 400,
          borderBottom: value === t.id ? "2px solid var(--ink)" : "2px solid transparent",
          marginBottom: -1,
          display: "inline-flex", alignItems: "center", gap: 6,
        }}>
          {t.label}
          {t.count != null && (
            <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>{t.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}

// ─── Button ────────────────────────────────────────────────────────────────
function Btn({ children, kind = "default", size = "md", onClick, disabled, style: s }) {
  const styles = {
    default: { background: "var(--paper-2)", color: "var(--ink)", border: "1px solid var(--rule)" },
    primary: { background: "var(--ink)", color: "var(--paper)", border: "1px solid var(--ink)" },
    ghost:   { background: "transparent", color: "var(--ink-2)", border: "1px solid transparent" },
    danger:  { background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent)" },
  };
  const sizes = {
    sm: { padding: "4px 8px", fontSize: 11 },
    md: { padding: "6px 12px", fontSize: 12 },
    lg: { padding: "9px 16px", fontSize: 13 },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      fontFamily: "var(--f-sans)", fontWeight: 500,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      ...styles[kind], ...sizes[size], ...s,
    }}>{children}</button>
  );
}

// ─── Field ──────────────────────────────────────────────────────────────────
function Field({ label, hint, children, error }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {label && (
        <label style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-3)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
          {label}
        </label>
      )}
      {children}
      {hint && !error && <div style={{ fontSize: 11, color: "var(--ink-4)" }}>{hint}</div>}
      {error && <div style={{ fontSize: 11, color: "var(--err)" }}>{error}</div>}
    </div>
  );
}

function Input({ ...rest }) {
  return (
    <input {...rest} style={{
      padding: "6px 10px",
      background: "var(--paper)",
      border: "1px solid var(--rule)",
      color: "var(--ink)",
      fontFamily: "var(--f-sans)",
      fontSize: 13,
      borderRadius: 2,
      ...rest.style,
    }} />
  );
}

// Export
Object.assign(window, {
  CompanyMark, TierBadge, FitChip, StatusPill, ModeToggle, MaxGauge, CapBar,
  Sparkline, SourceTag, ModelBadge, TosPosture, Skeleton, PageCountBadge,
  Kbd, Eyebrow, Hr, PdfThumb, Spinner, EmptyState, Tabs, Btn, Field, Input,
  STATUS_META, SOURCE_LABEL,
});
