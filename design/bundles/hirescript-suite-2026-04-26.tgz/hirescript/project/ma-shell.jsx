// HireScript mass-apply — shell
// TopBar, NavRail, PageHeader, container.

const NAV_ITEMS = [
  { id: "dashboard",     label: "Dashboard",     hash: "/dashboard",     glyph: "◉" },
  { id: "inbox",         label: "Inbox",         hash: "/inbox",         glyph: "▤", count: 4 },
  { id: "queue",         label: "Queue",         hash: "/queue",         glyph: "▶", count: 4 },
  { id: "history",       label: "History",       hash: "/history",       glyph: "⏱" },
  { id: "knowledge",     label: "Knowledge",     hash: "/knowledge",     glyph: "◇" },
  { id: "tiers",         label: "Tiers",         hash: "/tiers",         glyph: "▦" },
  { id: "settings",      label: "Settings",      hash: "/settings",      glyph: "✦" },
];

function NavRail({ current, collapsed, onToggle, onNavigate }) {
  const w = collapsed ? 56 : 200;
  return (
    <aside style={{
      width: w, flexShrink: 0,
      background: "var(--paper-2)",
      borderRight: "1px solid var(--rule)",
      display: "flex", flexDirection: "column",
      transition: "width 0.18s ease",
      position: "sticky", top: 56, height: "calc(100vh - 56px)",
      overflow: "hidden",
    }}>
      <div style={{ padding: "16px 12px 8px 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        {!collapsed && <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.1em", textTransform: "uppercase" }}>Surfaces</span>}
        <button onClick={onToggle} title={collapsed ? "Expand nav" : "Collapse nav"} style={{
          background: "transparent", border: "1px solid var(--rule)",
          color: "var(--ink-3)", fontFamily: "var(--f-mono)", fontSize: 10,
          padding: "2px 6px", cursor: "pointer", borderRadius: 2,
        }}>{collapsed ? "›" : "‹"}</button>
      </div>
      <nav style={{ display: "flex", flexDirection: "column", padding: "0 8px", gap: 1 }}>
        {NAV_ITEMS.map(it => {
          const active = current === it.id;
          return (
            <a key={it.id} href={`#${it.hash}`} onClick={(e) => { e.preventDefault(); onNavigate(it.hash); }}
              title={collapsed ? it.label : undefined}
              style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: collapsed ? "9px 10px" : "8px 10px",
                fontFamily: "var(--f-sans)", fontSize: 13,
                color: active ? "var(--ink)" : "var(--ink-2)",
                background: active ? "var(--paper)" : "transparent",
                borderLeft: active ? "2px solid var(--ink)" : "2px solid transparent",
                fontWeight: active ? 600 : 400,
                textDecoration: "none",
                whiteSpace: "nowrap",
                justifyContent: collapsed ? "center" : "flex-start",
              }}>
              <span style={{ width: 16, textAlign: "center", color: active ? "var(--ink)" : "var(--ink-3)", fontFamily: "var(--f-mono)", fontSize: 13 }}>{it.glyph}</span>
              {!collapsed && (
                <>
                  <span style={{ flex: 1 }}>{it.label}</span>
                  {it.count != null && (
                    <span className="mono" style={{
                      fontSize: 10, color: "var(--ink-4)",
                      padding: "0 4px",
                      background: "var(--paper-3)",
                    }}>{it.count}</span>
                  )}
                </>
              )}
            </a>
          );
        })}
      </nav>
      <div style={{ flex: 1 }} />
      {!collapsed && (
        <div style={{ padding: 12, borderTop: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", lineHeight: 1.6 }}>
          <div>HireScript v0.4.2</div>
          <div>Single-tenant · local-first</div>
        </div>
      )}
    </aside>
  );
}

function TopBar({ onCmd, onToggleDark, dark, unread, onOpenNotif, onScreensDock }) {
  const c = window.MA.COUNTERS;
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 10,
      height: 56, background: "var(--paper)",
      borderBottom: "1px solid var(--rule)",
      display: "flex", alignItems: "center", padding: "0 16px", gap: 16,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 28, height: 28, background: "var(--ink)", color: "var(--paper)",
          display: "grid", placeItems: "center", fontFamily: "var(--f-mono)", fontWeight: 700,
        }}>H</div>
        <div className="serif" style={{ fontSize: 17, color: "var(--ink)", lineHeight: 1 }}>
          HireScript
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", marginLeft: 8, letterSpacing: "0.04em", textTransform: "uppercase" }}>mass-apply</span>
        </div>
      </div>
      <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
        <button onClick={onCmd} style={{
          width: 380, maxWidth: "100%",
          padding: "6px 10px",
          background: "var(--paper-2)", border: "1px solid var(--rule)",
          color: "var(--ink-3)", textAlign: "left",
          fontFamily: "var(--f-sans)", fontSize: 12,
          display: "flex", alignItems: "center", gap: 8,
          cursor: "pointer",
        }}>
          <span style={{ fontFamily: "var(--f-mono)" }}>⌕</span>
          <span>Search jobs, KB, commands…</span>
          <span style={{ marginLeft: "auto" }}><Kbd>⌘K</Kbd></span>
        </button>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
          <span title="Applied today"><span style={{ color: "var(--ok)" }}>●</span> {c.applied24h}</span>
          <span title="In queue"><span style={{ color: "var(--haiku)" }}>◆</span> {c.inQueue}</span>
          {c.stuck > 0 && <span title="Stuck"><span style={{ color: "var(--accent)" }}>✕</span> {c.stuck}</span>}
        </div>
        <Hr vertical style={{ height: 24 }} />
        <MaxGauge pct={c.maxWindow.pctUsed} size={32} showLabel={false} />
        <Hr vertical style={{ height: 24 }} />
        <button onClick={onScreensDock} title="Screens dock" style={{
          background: "transparent", border: "1px solid var(--rule)",
          color: "var(--ink-2)", fontFamily: "var(--f-mono)", fontSize: 11,
          padding: "4px 8px", cursor: "pointer",
        }}>Screens</button>
        <button onClick={onToggleDark} title={dark ? "Light mode" : "Dark mode"} style={{
          background: "transparent", border: "1px solid var(--rule)",
          color: "var(--ink-2)", fontFamily: "var(--f-mono)", fontSize: 12,
          padding: "4px 8px", cursor: "pointer",
        }}>{dark ? "☼" : "☽"}</button>
        <button onClick={onOpenNotif} title="Notifications" style={{
          position: "relative",
          background: "transparent", border: "1px solid var(--rule)",
          color: "var(--ink-2)", fontFamily: "var(--f-mono)", fontSize: 13,
          padding: "4px 9px", cursor: "pointer",
        }}>
          ◔
          {unread > 0 && (
            <span style={{
              position: "absolute", top: -4, right: -4,
              minWidth: 14, height: 14, padding: "0 3px",
              background: "var(--accent)", color: "white",
              fontFamily: "var(--f-mono)", fontSize: 9, fontWeight: 600,
              display: "grid", placeItems: "center", borderRadius: 14,
            }}>{unread}</span>
          )}
        </button>
        <div style={{
          width: 28, height: 28, borderRadius: 28,
          background: "oklch(0.55 0.18 30)", color: "white",
          display: "grid", placeItems: "center", fontFamily: "var(--f-mono)", fontWeight: 600, fontSize: 12,
        }}>MK</div>
      </div>
    </header>
  );
}

function PageHeader({ eyebrow, title, sub, right }) {
  return (
    <div style={{
      padding: "32px 40px 20px",
      borderBottom: "1px solid var(--rule)",
      display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 32,
    }}>
      <div>
        {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
        <h1 className="serif" style={{ fontSize: 36, lineHeight: 1.1, margin: "8px 0 6px", color: "var(--ink)", fontWeight: 400 }}>
          {title}
        </h1>
        {sub && <div style={{ fontSize: 14, color: "var(--ink-2)", maxWidth: 720 }}>{sub}</div>}
      </div>
      {right}
    </div>
  );
}

// Section header inside a page
function Section({ title, sub, right, children, style: s }) {
  return (
    <section style={{ padding: "24px 40px", borderBottom: "1px solid var(--rule)", ...s }}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 16 }}>
        <div>
          <div className="serif" style={{ fontSize: 20, color: "var(--ink)" }}>{title}</div>
          {sub && <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 2 }}>{sub}</div>}
        </div>
        {right}
      </div>
      {children}
    </section>
  );
}

// Card surface
function Card({ children, padded = true, style: s }) {
  return (
    <div style={{
      background: "var(--paper)",
      border: "1px solid var(--rule)",
      padding: padded ? 16 : 0,
      ...s,
    }}>{children}</div>
  );
}

Object.assign(window, { NavRail, TopBar, PageHeader, Section, Card, NAV_ITEMS });
