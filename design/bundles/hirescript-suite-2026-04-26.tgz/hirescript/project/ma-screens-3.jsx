// Notifications drawer, ⌘K command palette, Component inventory, Microcopy reference.

const { useState: useS3, useEffect: useE3, useMemo: useM3, useRef: useR3 } = React;

// ─── NOTIFICATIONS DRAWER ──────────────────────────────────────────────────
function NotifDrawer({ open, onClose }) {
  if (!open) return null;
  const groups = {
    "New": window.MA.NOTIFICATIONS.filter(n => !n.read),
    "Earlier": window.MA.NOTIFICATIONS.filter(n => n.read),
  };
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.18)", zIndex: 100 }} />
      <aside style={{
        position: "fixed", top: 0, right: 0, bottom: 0,
        width: 420, maxWidth: "100vw", background: "var(--paper)",
        borderLeft: "1px solid var(--rule)", zIndex: 101,
        display: "flex", flexDirection: "column",
      }}>
        <div style={{ padding: "18px 20px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center" }}>
          <div className="serif" style={{ fontSize: 20, color: "var(--ink)", flex: 1 }}>Notifications</div>
          <button onClick={onClose} style={{
            background: "transparent", border: "1px solid var(--rule)", color: "var(--ink-2)",
            fontFamily: "var(--f-mono)", width: 26, height: 26, cursor: "pointer", fontSize: 14,
          }}>×</button>
        </div>
        <div style={{ padding: "10px 20px", borderBottom: "1px solid var(--rule)", display: "flex", gap: 8 }}>
          <Btn kind="ghost" size="sm">Mark all read</Btn>
          <Btn kind="ghost" size="sm">Settings</Btn>
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {Object.entries(groups).map(([label, items]) => items.length > 0 && (
            <div key={label}>
              <div style={{ padding: "10px 20px 4px", fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}</div>
              {items.map(n => <NotifRow key={n.id} n={n} />)}
            </div>
          ))}
        </div>
        <div style={{ padding: "12px 20px", borderTop: "1px solid var(--rule)", background: "var(--paper-2)" }}>
          <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 8 }}>Push delivery</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 6, fontSize: 12, color: "var(--ink-2)" }}>
            <span>Stuck / paused</span><Switch on />
            <span>B-mode review ready</span><Switch on />
            <span>Daily summary (08:00)</span><Switch on />
            <span>Source connector errors</span><Switch on />
            <span>Every applied job</span><Switch />
          </div>
        </div>
      </aside>
    </>
  );
}

function NotifRow({ n }) {
  const meta = {
    captcha: { glyph: "‖", color: "warn" },
    stuck:   { glyph: "✕", color: "accent" },
    review:  { glyph: "!", color: "err" },
    summary: { glyph: "◉", color: "ink-3" },
    source:  { glyph: "↯", color: "warn" },
    applied: { glyph: "✓", color: "ok" },
  }[n.type] || { glyph: "·", color: "ink-3" };
  return (
    <div style={{
      padding: "12px 20px", borderBottom: "1px solid var(--rule)",
      display: "grid", gridTemplateColumns: "20px 1fr auto", gap: 10,
      background: n.read ? "transparent" : "var(--paper-2)",
      cursor: "pointer",
    }}>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 12, color: `var(--${meta.color})`, marginTop: 1 }}>{meta.glyph}</span>
      <div>
        <div style={{ fontSize: 13, color: "var(--ink)", fontWeight: n.read ? 400 : 600 }}>{n.title}</div>
        <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 2 }}>{n.body}</div>
      </div>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)" }}>{window.MA.fmtAgo(n.at)}</span>
    </div>
  );
}

function Switch({ on }) {
  return (
    <span style={{
      width: 28, height: 16, borderRadius: 16, padding: 2,
      background: on ? "var(--ink)" : "var(--paper-3)",
      border: "1px solid var(--rule)",
      display: "inline-flex", alignItems: "center",
      cursor: "pointer",
    }}>
      <span style={{
        width: 10, height: 10, borderRadius: 10, background: "var(--paper)",
        transform: on ? "translateX(12px)" : "translateX(0)",
        transition: "transform 0.16s ease",
      }} />
    </span>
  );
}

// ─── COMMAND PALETTE ────────────────────────────────────────────────────────
function CmdPalette({ open, onClose, onNavigate, onOpenJob }) {
  const [q, setQ] = useS3("");
  const inputRef = useR3();
  useE3(() => { if (open && inputRef.current) inputRef.current.focus(); }, [open]);
  if (!open) return null;
  const cmds = [
    { id: "go-dashboard", label: "Go to Dashboard", group: "Navigate", do: () => { onNavigate("/dashboard"); onClose(); }, kbd: "G D" },
    { id: "go-inbox",     label: "Go to Inbox",     group: "Navigate", do: () => { onNavigate("/inbox"); onClose(); }, kbd: "G I" },
    { id: "go-queue",     label: "Go to Queue",     group: "Navigate", do: () => { onNavigate("/queue"); onClose(); }, kbd: "G Q" },
    { id: "go-history",   label: "Go to History",   group: "Navigate", do: () => { onNavigate("/history"); onClose(); }, kbd: "G H" },
    { id: "go-knowledge", label: "Go to Knowledge", group: "Navigate", do: () => { onNavigate("/knowledge"); onClose(); }, kbd: "G K" },
    { id: "go-tiers",     label: "Go to Tiers",     group: "Navigate", do: () => { onNavigate("/tiers"); onClose(); }, kbd: "G T" },
    { id: "go-settings",  label: "Go to Settings",  group: "Navigate", do: () => { onNavigate("/settings"); onClose(); }, kbd: "G S" },
    { id: "add-url", label: "Add job by URL…", group: "Actions", do: () => onClose() },
    { id: "pause-all", label: "Pause all pipelines", group: "Actions", do: () => onClose() },
    { id: "resume-all", label: "Resume all pipelines", group: "Actions", do: () => onClose() },
    { id: "force-b", label: "Force B-mode (review every app)", group: "Actions", do: () => onClose() },
    { id: "snapshot", label: "Snapshot KB", group: "Actions", do: () => onClose() },
    ...window.MA.JOBS.slice(0, 6).map(j => ({
      id: `job-${j.id}`, label: `${window.MA.COMPANIES[j.company].name} — ${j.title}`,
      group: "Jobs", do: () => { onOpenJob(j.id); onClose(); }, mark: <CompanyMark company={j.company} size={16} />,
    })),
  ];
  const filtered = q ? cmds.filter(c => c.label.toLowerCase().includes(q.toLowerCase())) : cmds;
  const grouped = filtered.reduce((acc, c) => ((acc[c.group] = acc[c.group] || []).push(c), acc), {});
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.32)", zIndex: 200, display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: "12vh" }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 600, maxWidth: "90vw", background: "var(--paper)",
        border: "1px solid var(--ink)", boxShadow: "0 24px 60px rgba(0,0,0,0.18)",
        display: "flex", flexDirection: "column", maxHeight: "70vh",
      }}>
        <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontFamily: "var(--f-mono)", color: "var(--ink-3)" }}>⌕</span>
          <input ref={inputRef} value={q} onChange={e => setQ(e.target.value)} placeholder="Type a command, job, or KB doc…" style={{
            flex: 1, border: "none", outline: "none", background: "transparent",
            fontFamily: "var(--f-sans)", fontSize: 16, color: "var(--ink)",
          }} />
          <Kbd>esc</Kbd>
        </div>
        <div style={{ overflowY: "auto", flex: 1 }}>
          {Object.entries(grouped).map(([g, items]) => (
            <div key={g}>
              <div style={{ padding: "10px 16px 4px", fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>{g}</div>
              {items.map(c => (
                <button key={c.id} onClick={c.do} style={{
                  width: "100%", padding: "8px 16px", display: "flex", alignItems: "center", gap: 10,
                  background: "transparent", border: "none", borderTop: "1px solid var(--rule)",
                  textAlign: "left", cursor: "pointer", color: "var(--ink-2)", fontSize: 13,
                }} onMouseEnter={e => e.currentTarget.style.background = "var(--paper-2)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                  {c.mark || <span style={{ width: 16, color: "var(--ink-4)", fontFamily: "var(--f-mono)" }}>›</span>}
                  <span style={{ flex: 1 }}>{c.label}</span>
                  {c.kbd && <Kbd>{c.kbd}</Kbd>}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── COMPONENT INVENTORY ────────────────────────────────────────────────────
function ComponentInventory() {
  return (
    <div>
      <PageHeader
        eyebrow="Reference"
        title="Component inventory"
        sub="Every primitive in the mass-apply phase. States, sizes, dos and don'ts. Use this for handoff to engineering."
      />

      <Spec title="TierBadge" sub="The classifier's verdict, atomic.">
        <SpecGrid items={[
          { label: "Dream",     node: <TierBadge tier="dream" /> },
          { label: "Targeted",  node: <TierBadge tier="targeted" /> },
          { label: "Wide net",  node: <TierBadge tier="wide_net" /> },
          { label: "Skip",      node: <TierBadge tier="skip" /> },
          { label: "Dot · dream", node: <TierBadge tier="dream" dot /> },
          { label: "Dot · targeted", node: <TierBadge tier="targeted" dot /> },
        ]} />
      </Spec>

      <Spec title="FitChip" sub="0–100 score. Bands: weak / moderate / strong.">
        <SpecGrid items={[
          { label: "94 · strong",    node: <FitChip score={94} /> },
          { label: "78 · strong",    node: <FitChip score={78} /> },
          { label: "62 · moderate",  node: <FitChip score={62} /> },
          { label: "38 · weak",      node: <FitChip score={38} /> },
          { label: "Large",          node: <FitChip score={94} size="lg" /> },
        ]} />
      </Spec>

      <Spec title="StatusPill" sub="11 distinct states across the funnel.">
        <SpecGrid items={Object.keys(STATUS_META).map(k => ({ label: k, node: <StatusPill status={k} /> }))} />
      </Spec>

      <Spec title="ModeToggle" sub="A vs. B. Filled side = active. Bold weight = override.">
        <SpecGrid items={[
          { label: "A · default",      node: <ModeToggle value="A" interactive={false} /> },
          { label: "B · default",      node: <ModeToggle value="B" interactive={false} /> },
          { label: "A · override",     node: <ModeToggle value="A" overridden interactive={false} /> },
          { label: "B · override",     node: <ModeToggle value="B" overridden interactive={false} /> },
          { label: "Large",            node: <ModeToggle value="B" size="lg" interactive={false} /> },
        ]} />
      </Spec>

      <Spec title="MaxGauge" sub="3/4 ring. 0-74% green · 75-89% warn · 90+% err.">
        <SpecGrid items={[
          { label: "32%",  node: <MaxGauge pct={32} size={72} showLabel={false} /> },
          { label: "62%",  node: <MaxGauge pct={62} size={72} showLabel={false} /> },
          { label: "82%",  node: <MaxGauge pct={82} size={72} showLabel={false} /> },
          { label: "95%",  node: <MaxGauge pct={95} size={72} showLabel={false} /> },
        ]} />
      </Spec>

      <Spec title="ModelBadge" sub="Outline + dot. Color carries identity.">
        <SpecGrid items={[
          { label: "Haiku",  node: <ModelBadge model="haiku" /> },
          { label: "Sonnet", node: <ModelBadge model="sonnet" /> },
          { label: "Opus",   node: <ModelBadge model="opus" /> },
        ]} />
      </Spec>

      <Spec title="SourceTag" sub="Six job-source families.">
        <SpecGrid items={[
          { label: "Greenhouse", node: <SourceTag source="greenhouse" /> },
          { label: "Lever",      node: <SourceTag source="lever" /> },
          { label: "Ashby",      node: <SourceTag source="ashby" /> },
          { label: "URL paste",  node: <SourceTag source="url_paste" /> },
          { label: "Email",      node: <SourceTag source="email" /> },
          { label: "Agentic",    node: <SourceTag source="agentic" /> },
        ]} />
      </Spec>

      <Spec title="TosPosture" sub="Clean / Grey / Red — same metaphor as page-count.">
        <SpecGrid items={[
          { label: "Clean", node: <TosPosture posture="clean" note="Public APIs" /> },
          { label: "Grey",  node: <TosPosture posture="grey"  note="Web search w/ robots" /> },
          { label: "Red",   node: <TosPosture posture="red"   note="Against ToS" /> },
        ]} />
      </Spec>

      <Spec title="CompanyMark" sub="Letter mark on brand-tinted square.">
        <SpecGrid items={["anthropic", "stripe", "linear", "ramp", "vercel", "notion", "figma", "duolingo"].map(c => ({
          label: window.MA.COMPANIES[c].name, node: <CompanyMark company={c} size={32} />,
        }))} />
      </Spec>

      <Spec title="Capacity bars + sparkline">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 24, padding: 16, background: "var(--paper)", border: "1px solid var(--rule)" }}>
          <CapBar tier="dream" used={1} cap={3} label="Dream" />
          <CapBar tier="targeted" used={7} cap={15} label="Targeted" />
          <CapBar tier="wide_net" used={18} cap={30} label="Wide net" />
        </div>
        <div style={{ marginTop: 12, padding: 16, background: "var(--paper)", border: "1px solid var(--rule)" }}>
          <Sparkline values={window.MA.COUNTERS.sparkApplied} w={400} h={40} stroke="var(--ink)" fill />
        </div>
      </Spec>

      <Spec title="Buttons">
        <SpecGrid items={[
          { label: "Primary", node: <Btn kind="primary">Apply now</Btn> },
          { label: "Default", node: <Btn>Override mode</Btn> },
          { label: "Ghost",   node: <Btn kind="ghost">View →</Btn> },
          { label: "Danger",  node: <Btn kind="danger">Skip · kill list</Btn> },
        ]} />
      </Spec>

      <Spec title="Misc · spinner, skeleton, kbd, switch">
        <div style={{ display: "flex", alignItems: "center", gap: 24, padding: 16, background: "var(--paper)", border: "1px solid var(--rule)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}><Spinner /> <span style={{ fontSize: 12, color: "var(--ink-3)" }}>tailoring</span></div>
          <div style={{ width: 200 }}><Skeleton w="100%" h={12} /><Skeleton w="60%" h={12} style={{ marginTop: 6 }} /></div>
          <div style={{ display: "flex", gap: 6 }}><Kbd>⌘</Kbd><Kbd>K</Kbd></div>
          <Switch on />
        </div>
      </Spec>
    </div>
  );
}

function Spec({ title, sub, children }) {
  return (
    <Section title={title} sub={sub}>{children}</Section>
  );
}

function SpecGrid({ items }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 12 }}>
      {items.map((it, i) => (
        <div key={i} style={{
          padding: 16, background: "var(--paper)", border: "1px solid var(--rule)",
          display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 10, minHeight: 88, justifyContent: "space-between",
        }}>
          <div>{it.node}</div>
          <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.04em" }}>{it.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── MICROCOPY REFERENCE ────────────────────────────────────────────────────
function Microcopy() {
  return (
    <div>
      <PageHeader
        eyebrow="Reference"
        title="Microcopy"
        sub="Every string the agent shows the user. Voice: matter-of-fact, lowercase, never apologetic. Engineer-to-engineer."
      />

      <Section title="Voice rules">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <Card>
            <Eyebrow color="ok">Yes</Eyebrow>
            <ul style={{ margin: "8px 0 0 18px", padding: 0, color: "var(--ink-2)", lineHeight: 1.7, fontSize: 13 }}>
              <li>"agent stuck — needs your answer"</li>
              <li>"applied · 11 sec wall · 1.8k tok out"</li>
              <li>"verifier blocked claim, KB says 8 reports not 12"</li>
              <li>"max-window resets 1h 47m"</li>
            </ul>
          </Card>
          <Card>
            <Eyebrow color="accent">No</Eyebrow>
            <ul style={{ margin: "8px 0 0 18px", padding: 0, color: "var(--ink-2)", lineHeight: 1.7, fontSize: 13 }}>
              <li>"Oops! Something went wrong 🙈"</li>
              <li>"We've successfully submitted your application!"</li>
              <li>"Don't worry — we'll handle this for you"</li>
              <li>"Looks like you're using a lot of tokens 😬"</li>
            </ul>
          </Card>
        </div>
      </Section>

      <Section title="Status / tier verbs">
        <CopyTable rows={[
          ["ingested",         "Source posted, not yet classified"],
          ["classified",       "Classifier returned a tier; awaiting cap"],
          ["queued",           "Held for B-mode review or capacity"],
          ["applying",         "Tailor + agent are running now"],
          ["applied",          "Submitted; confirmation captured"],
          ["paused",           "Captcha / 2FA / external block"],
          ["stuck",            "Field unmapped — needs your answer"],
          ["needs attention",  "Verifier blocked the bundle pre-submit"],
          ["skipped",          "Below tier floor or kill-listed"],
          ["errored",          "Pipeline failed; promoted to agent or you"],
          ["snoozed",          "Re-surfaces in 24h+"],
        ]} />
      </Section>

      <Section title="Edge-case prompts">
        <CopyTable rows={[
          ["captcha 90s",        "Stripe wants a captcha. 90s window before the agent backs off."],
          ["years-of-X stuck",    "Agent stuck on a 'Years of …' field with no profile mapping. Type a number."],
          ["claim unsupported",   "Verifier won't ship 'led 12-person team'. KB says 8 reports. Edit or reject?"],
          ["GitHub rate-limited", "GitHub poll failing — retries in 22m. Won't block any application."],
          ["max-window 90%+",     "Max-window 92% — only Haiku + applied paths from here. Resets 47m."],
          ["killed company",      "DoorDash is on your kill list (defense work). Skip every posting?"],
          ["dream salary low",    "Anthropic posting at $310k floor — below your $260k? Apply anyway?"],
          ["empty inbox",         "Nothing new today. Sources polled 4m ago."],
        ]} />
      </Section>

      <Section title="Notification copy">
        <CopyTable rows={[
          ["Stripe is asking for a captcha",        "Tap to finish — pipeline pauses in 90s"],
          ["Airtable agent stuck",                  "Field unmapped: 'Years of relevant experience'"],
          ["Perplexity — review needed",            "Verifier blocked claim; team-size mismatch"],
          ["Vercel — review ready",                 "B-mode resume + cover letter ready to send"],
          ["Daily summary",                         "12 applied · 3 in queue · 1 stuck"],
          ["GitHub poll failing",                   "Rate limited; retries in ~22m"],
          ["Applied to Linear",                     "Staff Product Engineer · B-mode · Greenhouse"],
        ]} />
      </Section>

      <Section title="Empty states">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
          <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
            <EmptyState glyph="◌" title="Nothing in queue" body="The agent is idle. Sources are polled every 15 min." cta="Browse inbox" />
          </div>
          <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
            <EmptyState glyph="◐" title="No KB documents yet" body="Connect Notion, GitHub, or paste markdown to index." cta="Connect a source" />
          </div>
          <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
            <EmptyState glyph="✓" title="All caught up" body="No notifications. Last activity 22 min ago." />
          </div>
        </div>
      </Section>
    </div>
  );
}

function CopyTable({ rows }) {
  return (
    <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
      {rows.map(([k, v], i) => (
        <div key={i} style={{
          display: "grid", gridTemplateColumns: "200px 1fr",
          padding: "10px 14px", borderBottom: i < rows.length - 1 ? "1px solid var(--rule)" : "none",
          alignItems: "baseline",
        }}>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink)" }}>{k}</span>
          <span style={{ fontSize: 13, color: "var(--ink-2)" }}>{v}</span>
        </div>
      ))}
    </div>
  );
}

// ─── SCREENS DOCK (bottom-right) ────────────────────────────────────────────
function ScreensDock({ open, current, onNavigate, onClose }) {
  if (!open) return null;
  const screens = [
    { id: "dashboard", label: "Dashboard", hash: "/dashboard" },
    { id: "inbox", label: "Inbox", hash: "/inbox" },
    { id: "queue", label: "Queue", hash: "/queue" },
    { id: "history", label: "History", hash: "/history" },
    { id: "knowledge-profile", label: "Knowledge — Profile", hash: "/knowledge/profile" },
    { id: "knowledge-docs", label: "Knowledge — Documents", hash: "/knowledge/documents" },
    { id: "knowledge-sources", label: "Knowledge — Sources", hash: "/knowledge/sources" },
    { id: "tiers", label: "Tiers", hash: "/tiers" },
    { id: "settings", label: "Settings", hash: "/settings" },
    { id: "components", label: "Component inventory", hash: "/components", reference: true },
    { id: "microcopy", label: "Microcopy", hash: "/microcopy", reference: true },
  ];
  return (
    <div style={{
      position: "fixed", right: 16, bottom: 16, zIndex: 90,
      width: 280, background: "var(--paper)", border: "1px solid var(--ink)",
      boxShadow: "0 16px 40px rgba(0,0,0,0.18)",
    }}>
      <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center" }}>
        <div className="serif" style={{ fontSize: 14, color: "var(--ink)", flex: 1 }}>Screens</div>
        <button onClick={onClose} style={{ background: "transparent", border: "1px solid var(--rule)", color: "var(--ink-2)", fontFamily: "var(--f-mono)", fontSize: 11, width: 22, height: 22, cursor: "pointer" }}>×</button>
      </div>
      <div style={{ padding: 8, maxHeight: 420, overflowY: "auto" }}>
        {screens.map(s => (
          <button key={s.id} onClick={() => onNavigate(s.hash)} style={{
            width: "100%", padding: "7px 10px", display: "flex", alignItems: "center", gap: 8,
            background: "transparent", border: "1px solid transparent",
            textAlign: "left", cursor: "pointer", fontSize: 12,
            color: current === s.id ? "var(--ink)" : "var(--ink-2)",
            fontWeight: current === s.id ? 600 : 400,
          }} onMouseEnter={e => e.currentTarget.style.background = "var(--paper-2)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--ink-4)", width: 16 }}>{current === s.id ? "●" : "○"}</span>
            <span style={{ flex: 1 }}>{s.label}</span>
            {s.reference && <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>ref</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { NotifDrawer, CmdPalette, ComponentInventory, Microcopy, ScreensDock });
