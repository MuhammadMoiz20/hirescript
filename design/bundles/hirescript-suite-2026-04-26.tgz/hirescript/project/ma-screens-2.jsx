// Knowledge (Profile/Documents/Sources tabs), Tiers policy editor, Settings.

const { useState: useS2 } = React;

// ─── KNOWLEDGE shell with 3 tabs ────────────────────────────────────────────
function Knowledge({ initialTab = "profile" }) {
  const [tab, setTab] = useS2(initialTab);
  return (
    <div>
      <PageHeader
        eyebrow="Knowledge"
        title="The agent's source of truth"
        sub="Profile facts, retrievable documents, and the connectors that feed them. Everything the agent says about you must come from here."
      />
      <div style={{ padding: "0 40px", borderBottom: "1px solid var(--rule)" }}>
        <Tabs value={tab} onChange={setTab} tabs={[
          { id: "profile", label: "Profile" },
          { id: "documents", label: "Documents", count: window.MA.KB_DOCS.length },
          { id: "sources", label: "Sources", count: window.MA.KB_SOURCES.length },
        ]} />
      </div>
      {tab === "profile" && <KnowledgeProfile />}
      {tab === "documents" && <KnowledgeDocuments />}
      {tab === "sources" && <KnowledgeSources />}
    </div>
  );
}

// ─── Profile ────────────────────────────────────────────────────────────────
function KnowledgeProfile() {
  const p = window.MA.PROFILE;
  return (
    <div>
      <Section title="Identity & contact" sub="The default fields every job form asks for.">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
          <KV label="Legal name" value={p.legal_name} />
          <KV label="Preferred name" value={p.preferred_name} />
          <KV label="Pronouns" value={p.pronouns} />
          <KV label="Email" value={p.email} mono />
          <KV label="Phone" value={p.phone} mono />
          <KV label="Timezone" value={p.timezone} mono />
          <KV label="Address" value={p.address} span={3} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginTop: 20 }}>
          <KV label="LinkedIn" value={p.links.linkedin} mono />
          <KV label="GitHub" value={p.links.github} mono />
          <KV label="Site" value={p.links.site} mono />
          <KV label="X" value={p.links.x} mono />
        </div>
      </Section>

      <Section title="Work authorization" sub="What you'll answer to 'sponsorship?' and 'authorized to work?'">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 24 }}>
          <KV label="Citizenships" value={p.work_auth.citizenships.join(" · ")} />
          <div>
            <Eyebrow>Need sponsorship</Eyebrow>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
              {Object.entries(p.work_auth.sponsorship).map(([k, v]) => (
                <span key={k} style={{
                  padding: "3px 8px", fontFamily: "var(--f-mono)", fontSize: 11,
                  color: v ? "var(--warn)" : "var(--ok)",
                  border: `1px solid ${v ? "var(--warn)" : "var(--ok)"}`,
                  background: v ? "var(--warn-soft)" : "var(--ok-soft)",
                }}>{k}: {v ? "Yes" : "No"}</span>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section title="Positions" sub="Most recent first. Drives every resume tailor.">
        <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
          {p.positions.map((pos, i) => (
            <div key={i} style={{ padding: "16px 0", borderBottom: "1px solid var(--rule)", display: "grid", gridTemplateColumns: "180px 1fr auto", gap: 24 }}>
              <div>
                <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-2)" }}>{pos.start} — {pos.end || "Present"}</div>
                <div style={{ fontSize: 11, color: "var(--ink-4)", marginTop: 2 }}>{pos.location}</div>
              </div>
              <div>
                <div className="serif" style={{ fontSize: 16, color: "var(--ink)" }}>{pos.company}</div>
                <div style={{ fontSize: 13, color: "var(--ink-2)", marginBottom: 4 }}>{pos.title}</div>
                <div style={{ fontSize: 12, color: "var(--ink-3)", lineHeight: 1.5 }}>{pos.blurb}</div>
              </div>
              <Btn kind="ghost" size="sm">Edit</Btn>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Preferences" sub="Hard floors and dealbreakers the classifier respects.">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
          <KV label="Salary floor" value={`$${(p.preferences.salary_floor_usd / 1000).toFixed(0)}k`} mono />
          <KV label="Salary target" value={`$${(p.preferences.salary_target_usd / 1000).toFixed(0)}k`} mono />
          <KV label="Work modes" value={p.preferences.work_modes.join(" · ")} />
          <KV label="Stages" value={p.preferences.company_stages.join(" · ")} mono />
          <KV label="Cover letter default" value={p.preferences.cover_letter_default ? "On" : "Off"} />
          <KV label="Disclose salary" value={p.preferences.disclose_salary_default ? "Yes" : "No (decline politely)"} />
        </div>
        <div style={{ marginTop: 20 }}>
          <Eyebrow>Dealbreakers</Eyebrow>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
            {p.preferences.dealbreakers.map(d => (
              <span key={d} style={{
                padding: "3px 8px", fontFamily: "var(--f-mono)", fontSize: 11,
                color: "var(--accent)", border: "1px solid var(--accent)", background: "var(--accent-soft)",
              }}>{d} ✕</span>
            ))}
            <button style={{
              padding: "3px 8px", fontFamily: "var(--f-mono)", fontSize: 11,
              color: "var(--ink-3)", border: "1px dashed var(--rule)", background: "transparent", cursor: "pointer",
            }}>+ add</button>
          </div>
        </div>
        <div style={{ marginTop: 20 }}>
          <Eyebrow>Kill list</Eyebrow>
          <div style={{ marginTop: 8 }}>
            {p.kill_list.map(k => (
              <div key={k.company} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderBottom: "1px solid var(--rule)" }}>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--accent)", width: 14 }}>✕</span>
                <span style={{ fontWeight: 500, color: "var(--ink)" }}>{k.company}</span>
                <span style={{ fontSize: 12, color: "var(--ink-3)" }}>{k.reason}</span>
                <Btn kind="ghost" size="sm" style={{ marginLeft: "auto" }}>Remove</Btn>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section title="EEO defaults" sub="Used only when application requires; otherwise declined.">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }}>
          <KV label="Gender" value={p.eeo.gender} />
          <KV label="Race / ethnicity" value={p.eeo.race_ethnicity} />
          <KV label="Veteran" value={p.eeo.veteran} />
          <KV label="Disability" value={p.eeo.disability} />
        </div>
      </Section>
    </div>
  );
}

function KV({ label, value, mono, span }) {
  return (
    <div style={{ gridColumn: span ? `span ${span}` : "auto" }}>
      <Eyebrow>{label}</Eyebrow>
      <div style={{
        marginTop: 4,
        fontFamily: mono ? "var(--f-mono)" : "var(--f-sans)",
        fontSize: mono ? 12 : 14,
        color: "var(--ink)",
      }}>{value}</div>
    </div>
  );
}

// ─── Documents ──────────────────────────────────────────────────────────────
function KnowledgeDocuments() {
  const [query, setQuery] = useS2("ledger idempotency exactly-once payments");
  const sample = window.MA.KB_RETRIEVAL_SAMPLE;
  return (
    <div>
      <Section title="Retrievable documents" sub={`${window.MA.KB_DOCS.length} documents · ${window.MA.KB_DOCS.reduce((s, d) => s + d.chunks, 0)} chunks indexed · embedding dim 1024`}>
        <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 140px 90px 90px", padding: "10px 14px", borderBottom: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
            <span>Title</span>
            <span>Source</span>
            <span>Chunks</span>
            <span>Fetched</span>
          </div>
          {window.MA.KB_DOCS.map(d => (
            <div key={d.id} style={{ display: "grid", gridTemplateColumns: "1fr 140px 90px 90px", padding: "10px 14px", borderBottom: "1px solid var(--rule)", alignItems: "center" }}>
              <span style={{ fontSize: 13, color: "var(--ink)" }}>{d.title}</span>
              <span><SourceTag source={d.source} /></span>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>{d.chunks}</span>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>{window.MA.fmtAgo(d.fetchedAt)} ago</span>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Test retrieval" sub="See exactly what the tailor will pull for a given query. Same path the agent uses.">
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <Input value={query} onChange={e => setQuery(e.target.value)} style={{ flex: 1, fontFamily: "var(--f-mono)", fontSize: 12 }} />
          <Btn kind="primary" size="md">Retrieve top-4</Btn>
        </div>
        <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
          {sample.results.map((r, i) => (
            <div key={r.docId} style={{ padding: 14, borderBottom: i < sample.results.length - 1 ? "1px solid var(--rule)" : "none" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", width: 18 }}>{String(i + 1).padStart(2, "0")}</span>
                <span style={{ fontWeight: 500, color: "var(--ink)" }}>{r.title}</span>
                <SourceTag source={r.source} />
                <span style={{ marginLeft: "auto", fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-3)" }}>distance {r.distance.toFixed(3)}</span>
              </div>
              <div style={{ fontSize: 12, color: "var(--ink-2)", lineHeight: 1.6, marginLeft: 28, fontStyle: "italic" }}>{r.snippet}</div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Onboarding gaps" sub="Profile gaps the agent has asked about. Each answer becomes a new KB document.">
        <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
          {[
            { q: "How many people reported to you at NVIDIA?", a: "8 (corrected from 12 after Perplexity flag)", at: 120 },
            { q: "What did you do at Two Sigma in 2018-Q3?", a: "Pending", pending: true, at: 90 },
            { q: "Are you open to onsite-only NYC?", a: "Yes, if comp ≥ target", at: 1440 },
          ].map((it, i) => (
            <div key={i} style={{ padding: 14, borderBottom: i < 2 ? "1px solid var(--rule)" : "none" }}>
              <div style={{ fontSize: 13, color: "var(--ink)" }}>{it.q}</div>
              <div style={{ fontSize: 12, color: it.pending ? "var(--warn)" : "var(--ink-3)", marginTop: 4, fontFamily: it.pending ? "var(--f-mono)" : "var(--f-sans)" }}>
                {it.pending ? "↳ awaiting answer" : `↳ ${it.a}`}
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

// ─── Sources ────────────────────────────────────────────────────────────────
function KnowledgeSources() {
  return (
    <div>
      <Section title="KB ingestors" sub="Where the documents come from. Connect, sync, configure scope.">
        <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
          {window.MA.KB_SOURCES.map((s, i) => (
            <KbSourceRow key={s.id} source={s} last={i === window.MA.KB_SOURCES.length - 1} />
          ))}
        </div>
        <div style={{ marginTop: 12 }}>
          <Btn kind="default" size="md">+ Connect new source</Btn>
        </div>
      </Section>

      <Section title="Job sources" sub="How jobs find their way into the inbox. Six families, three ToS postures.">
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {window.MA.SOURCES_CONFIG.map(fam => (
            <SourceFamily key={fam.family} fam={fam} />
          ))}
        </div>
      </Section>
    </div>
  );
}

function KbSourceRow({ source, last }) {
  const ok = source.status === "connected";
  return (
    <div style={{ padding: 14, borderBottom: last ? "none" : "1px solid var(--rule)" }}>
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto auto auto", gap: 14, alignItems: "center" }}>
        <span style={{
          width: 28, height: 28, display: "grid", placeItems: "center",
          background: "var(--paper-3)", border: "1px solid var(--rule)",
          fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-2)",
        }}>{source.id === "latex_master" ? "L" : source.id === "github" ? "G" : source.id === "notion" ? "N" : source.id === "website" ? "W" : source.id === "markdown" ? "M" : "O"}</span>
        <div>
          <div style={{ fontSize: 13, color: "var(--ink)", fontWeight: 500 }}>{source.name}</div>
          <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>
            {source.docs} docs · {source.chunks} chunks · last sync {window.MA.fmtAgo(source.lastSync)} ago
          </div>
        </div>
        <span style={{
          fontFamily: "var(--f-mono)", fontSize: 10, padding: "2px 8px",
          color: ok ? "var(--ok)" : "var(--err)",
          border: `1px solid ${ok ? "var(--ok)" : "var(--err)"}`,
        }}>
          {ok ? "● Connected" : "✕ Error"}
        </span>
        <Btn kind="ghost" size="sm">Sync now</Btn>
        <Btn kind="ghost" size="sm">Configure</Btn>
      </div>
      {source.error && (
        <div style={{ marginTop: 8, padding: 8, background: "var(--err-soft)", border: "1px solid var(--err)", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--err)" }}>
          ↳ {source.error}
        </div>
      )}
      {source.config?.deny && (
        <div style={{ marginTop: 8, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
          allow {source.config.allow.join(", ")} · deny {source.config.deny.join(", ")}
        </div>
      )}
    </div>
  );
}

function SourceFamily({ fam }) {
  return (
    <div style={{ background: "var(--paper)", border: "1px solid var(--rule)" }}>
      <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontWeight: 600, color: "var(--ink)" }}>{fam.label}</div>
        <TosPosture posture={fam.tos} note={fam.tosNote} />
        <span style={{ marginLeft: "auto", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>{fam.tosNote}</span>
      </div>
      <div style={{ padding: "8px 16px" }}>
        {fam.items.length === 0 ? (
          <div style={{ padding: "10px 0", fontSize: 12, color: "var(--ink-3)" }}>No items configured. Use the URL field on any job to add ad-hoc.</div>
        ) : fam.items.map((it, i) => (
          <div key={i} style={{ padding: "10px 0", borderBottom: i < fam.items.length - 1 ? "1px solid var(--rule)" : "none", display: "grid", gridTemplateColumns: "1fr auto auto auto", gap: 12, alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 500, color: "var(--ink)" }}>{it.provider}</div>
              <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>
                {fam.family === "ats" && `${it.boards} boards · poll every ${it.cadence}m · ${it.jobs24h} jobs/24h`}
                {fam.family === "aggregator" && (it.apiKeySet ? `API key set · ${it.jobs24h} jobs/24h` : "API key required")}
                {fam.family === "scraping" && (it.enabled ? "Enabled · feature-flag, you accept risk" : "Disabled")}
                {fam.family === "email" && `${it.imap} · labels: ${it.labels.join(", ")} · ${it.jobs24h} jobs/24h`}
                {fam.family === "agentic" && `Daily token budget · ${it.regions.join(", ")}`}
              </div>
            </div>
            {fam.family === "agentic" && (
              <div style={{ width: 200 }}>
                <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-3)", marginBottom: 4 }}>
                  {(it.tokensUsedToday / 1000).toFixed(0)}k / {(it.tokensPerDay / 1000).toFixed(0)}k tok today
                </div>
                <div style={{ height: 4, background: "var(--paper-3)" }}>
                  <div style={{ height: 4, width: `${(it.tokensUsedToday / it.tokensPerDay) * 100}%`, background: "var(--ink-2)" }} />
                </div>
              </div>
            )}
            <span style={{
              fontFamily: "var(--f-mono)", fontSize: 10, padding: "2px 8px",
              color: it.enabled === false ? "var(--ink-4)" : "var(--ok)",
              border: `1px solid ${it.enabled === false ? "var(--rule)" : "var(--ok)"}`,
            }}>
              {it.enabled === false ? "Off" : "● On"}
            </span>
            <Btn kind="ghost" size="sm">Configure</Btn>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── TIERS ──────────────────────────────────────────────────────────────────
function TiersPolicy() {
  return (
    <div>
      <PageHeader
        eyebrow="Tiers"
        title="The classifier's verdict, in policy form"
        sub="Each job lands in one of four buckets. Each bucket sets its own model, mode, cap, research depth, and verifier."
        right={<Btn kind="primary" size="md">Save changes</Btn>}
      />

      {/* Threshold ribbon */}
      <Section title="Fit score thresholds" sub="The classifier returns a 0–100 score. Drag handles or edit the boundaries below.">
        <ThresholdRibbon />
      </Section>

      {/* Tier cards */}
      <Section title="Per-tier policy" sub="Models, mode, daily cap, research depth, verifier strictness, cover letter.">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          {window.MA.TIERS.map(t => <TierCard key={t.id} tier={t} />)}
        </div>
      </Section>

      <Section title="Global override knobs" sub="Apply on top of tier defaults. Use sparingly.">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <Card>
            <Eyebrow>Mode floor</Eyebrow>
            <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 6, fontSize: 12, color: "var(--ink-2)" }}>
              <Radio label="Tier defaults" checked />
              <Radio label="Force B-mode (review every app)" />
              <Radio label="Force A-mode (apply autonomously)" />
            </div>
          </Card>
          <Card>
            <Eyebrow>Daily mass cap</Eyebrow>
            <div style={{ marginTop: 8, fontFamily: "var(--f-mono)", fontSize: 28, color: "var(--ink)" }}>48</div>
            <div style={{ fontSize: 11, color: "var(--ink-3)" }}>across all tiers · resets midnight Pacific</div>
            <div style={{ marginTop: 10, height: 4, background: "var(--paper-3)" }}>
              <div style={{ height: 4, width: "54%", background: "var(--ink)" }} />
            </div>
          </Card>
          <Card>
            <Eyebrow>Spending kill-switch</Eyebrow>
            <div style={{ marginTop: 8, fontFamily: "var(--f-mono)", fontSize: 28, color: "var(--ink)" }}>$12.40</div>
            <div style={{ fontSize: 11, color: "var(--ink-3)" }}>today · stops at $40/day</div>
            <div style={{ marginTop: 10, height: 4, background: "var(--paper-3)" }}>
              <div style={{ height: 4, width: "31%", background: "var(--ok)" }} />
            </div>
          </Card>
        </div>
      </Section>
    </div>
  );
}

function ThresholdRibbon() {
  return (
    <div style={{ background: "var(--paper)", border: "1px solid var(--rule)", padding: 24 }}>
      <div style={{ position: "relative", height: 64 }}>
        {/* Track */}
        <div style={{ position: "absolute", top: 28, left: 0, right: 0, height: 8, background: "var(--paper-3)" }} />
        {/* Tier segments */}
        <div style={{ position: "absolute", top: 28, height: 8, left: "0%", width: "40%", background: "var(--tier-skip)", opacity: 0.6 }} />
        <div style={{ position: "absolute", top: 28, height: 8, left: "40%", width: "20%", background: "var(--tier-wide_net)" }} />
        <div style={{ position: "absolute", top: 28, height: 8, left: "60%", width: "25%", background: "var(--tier-targeted)" }} />
        <div style={{ position: "absolute", top: 28, height: 8, left: "85%", width: "15%", background: "var(--tier-dream)" }} />
        {/* Labels */}
        {[
          { x: "5%", label: "Skip", tier: "skip", range: "0–39" },
          { x: "47%", label: "Wide", tier: "wide_net", range: "40–59" },
          { x: "70%", label: "Targeted", tier: "targeted", range: "60–84" },
          { x: "90%", label: "Dream", tier: "dream", range: "85–100" },
        ].map((l, i) => (
          <div key={i} style={{ position: "absolute", left: l.x, top: 0, transform: "translateX(-50%)", textAlign: "center" }}>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: `var(--tier-${l.tier})`, fontWeight: 600 }}>{l.range}</div>
            <div style={{ fontSize: 12, color: "var(--ink)", marginTop: 2 }}>{l.label}</div>
          </div>
        ))}
        {/* Handles */}
        {[40, 60, 85].map(v => (
          <div key={v} style={{ position: "absolute", left: `${v}%`, top: 22, transform: "translateX(-50%)", width: 12, height: 20, background: "var(--ink)", cursor: "ew-resize" }} />
        ))}
        {/* Scale ticks */}
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, display: "flex", justifyContent: "space-between" }}>
          {[0, 25, 50, 75, 100].map(v => (
            <span key={v} style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)" }}>{v}</span>
          ))}
        </div>
      </div>
      <div style={{ marginTop: 16, fontSize: 12, color: "var(--ink-3)", lineHeight: 1.6 }}>
        Drag handles or set boundaries directly: <span className="mono">skip≤39 · wide 40-59 · targeted 60-84 · dream≥85</span>
      </div>
    </div>
  );
}

function TierCard({ tier }) {
  return (
    <Card>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ width: 8, height: 8, borderRadius: 8, background: `var(--tier-${tier.id})` }} />
          <div className="serif" style={{ fontSize: 20, color: "var(--ink)" }}>{tier.label}</div>
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>fit {tier.fitMin}–{tier.fitMax}</span>
        </div>
        <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>{tier.dailyUsed} / {tier.dailyCap || "—"} today</span>
      </div>

      {/* Models */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", rowGap: 8, columnGap: 12, fontSize: 12 }}>
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Classify</div>
        <div><ModelBadge model={tier.models.classify} /></div>
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Research</div>
        <div>{tier.research === "off" ? <span style={{ color: "var(--ink-4)", fontFamily: "var(--f-mono)", fontSize: 11 }}>— off</span> : <ModelBadge model={tier.models.research} />}</div>
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Tailor</div>
        <div>{tier.models.tailor === "off" ? <span style={{ color: "var(--ink-4)", fontFamily: "var(--f-mono)", fontSize: 11 }}>— off (skip)</span> : <ModelBadge model={tier.models.tailor} />}</div>
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Cover</div>
        <div>{tier.models.cover === "off" ? <span style={{ color: "var(--ink-4)", fontFamily: "var(--f-mono)", fontSize: 11 }}>— none</span> : <ModelBadge model={tier.models.cover} />}</div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--rule)" }}>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Default mode</span>
        <ModeToggle value={tier.defaultMode} interactive={false} />
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", marginLeft: "auto", letterSpacing: "0.06em", textTransform: "uppercase" }}>Verifier</span>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: tier.verifier === "strict" ? "var(--ink)" : tier.verifier === "lenient" ? "var(--ink-3)" : "var(--ink-4)" }}>{tier.verifier}</span>
      </div>

      <div style={{ marginTop: 12, fontSize: 11, color: "var(--ink-3)", lineHeight: 1.6 }}>
        Examples: {tier.examples.join(" · ")}
      </div>
    </Card>
  );
}

function Radio({ label, checked }) {
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
      <span style={{
        width: 14, height: 14, borderRadius: 14,
        border: "1px solid var(--rule)",
        display: "grid", placeItems: "center",
        background: "var(--paper)",
      }}>
        {checked && <span style={{ width: 7, height: 7, borderRadius: 7, background: "var(--ink)" }} />}
      </span>
      <span style={{ fontSize: 12, color: "var(--ink-2)" }}>{label}</span>
    </label>
  );
}

// ─── SETTINGS ───────────────────────────────────────────────────────────────
function Settings() {
  return (
    <div>
      <PageHeader
        eyebrow="Settings"
        title="The plumbing"
        sub="Workspace, API key, model defaults, exports. Single-tenant — these settings are local to your install."
      />

      <Section title="Workspace">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
          <Field label="Workspace name"><Input defaultValue="Moiz · personal" /></Field>
          <Field label="Time zone"><Input defaultValue="America/Los_Angeles" /></Field>
          <Field label="Quiet hours"><Input defaultValue="22:00 – 08:00" /></Field>
        </div>
      </Section>

      <Section title="Anthropic API key" sub="Used for every agent step. Required.">
        <Field label="Key" hint="Stored locally only. We never proxy your traffic.">
          <Input defaultValue="sk-ant-api03-•••••••••••••••••••••••••••••f4Q" style={{ fontFamily: "var(--f-mono)", fontSize: 12 }} />
        </Field>
        <div style={{ display: "flex", gap: 16, marginTop: 16, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
          <span>● Validated · Max-window subscription</span>
          <span>·</span>
          <span>5M tok / 5h window</span>
          <span>·</span>
          <span>Models available: Haiku, Sonnet, Opus</span>
        </div>
      </Section>

      <Section title="Model defaults" sub="Tier policies override these — only used as fallback when policy says 'inherit'.">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
          <ModelDefault stage="Classify" model="haiku" />
          <ModelDefault stage="Research" model="sonnet" />
          <ModelDefault stage="Tailor" model="sonnet" />
          <ModelDefault stage="Cover letter" model="sonnet" />
        </div>
      </Section>

      <Section title="Exports & backups">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <Card>
            <Eyebrow>Application bundle</Eyebrow>
            <div style={{ fontSize: 13, color: "var(--ink-2)", marginTop: 6, lineHeight: 1.6 }}>
              Per-app PDF + cover + answers + diff + KB chunks cited.
            </div>
            <div style={{ marginTop: 12 }}><Btn kind="default" size="sm">Export all (.zip)</Btn></div>
          </Card>
          <Card>
            <Eyebrow>KB snapshot</Eyebrow>
            <div style={{ fontSize: 13, color: "var(--ink-2)", marginTop: 6, lineHeight: 1.6 }}>
              Profile + indexed docs + embeddings. Re-importable.
            </div>
            <div style={{ marginTop: 12 }}><Btn kind="default" size="sm">Snapshot now</Btn></div>
          </Card>
          <Card>
            <Eyebrow>CSV reports</Eyebrow>
            <div style={{ fontSize: 13, color: "var(--ink-2)", marginTop: 6, lineHeight: 1.6 }}>
              History table flattened for Excel / Sheets.
            </div>
            <div style={{ marginTop: 12 }}><Btn kind="default" size="sm">Export CSV</Btn></div>
          </Card>
        </div>
      </Section>

      <Section title="Danger zone">
        <Card style={{ border: "1px solid var(--accent)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, color: "var(--accent)" }}>Wipe all application history</div>
              <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 2 }}>
                Removes every applied/queued/skipped record. KB and profile remain. This cannot be undone.
              </div>
            </div>
            <Btn kind="danger" size="md">Wipe history…</Btn>
          </div>
        </Card>
      </Section>
    </div>
  );
}

function ModelDefault({ stage, model }) {
  return (
    <Card>
      <Eyebrow>{stage}</Eyebrow>
      <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 6 }}>
        {["haiku", "sonnet", "opus"].map(m => (
          <Radio key={m} label={<><ModelBadge model={m} /> <span style={{ marginLeft: 6, color: "var(--ink-3)", fontSize: 11 }}>{m === "haiku" ? "fastest, cheapest" : m === "sonnet" ? "balanced" : "highest quality"}</span></>} checked={m === model} />
        ))}
      </div>
    </Card>
  );
}

Object.assign(window, { Knowledge, TiersPolicy, Settings });
