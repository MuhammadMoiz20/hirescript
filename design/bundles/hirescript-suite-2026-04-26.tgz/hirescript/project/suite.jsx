/* HireScript Suite — top-level shell that hosts both apps */
/* eslint-disable */

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// =============================================================
// Suite-level routing
// =============================================================
//
// Suite hash format:  #/<app>/<inner-path>
//   #/                              -> overview
//   #/per-job/<inner>               -> HireScript.html#/<inner>
//   #/mass-apply/<inner>            -> Mass Apply.html#/<inner>
//   #/proposal                      -> Proposal.html
//
// Each inner app keeps its own router. We pass the inner path
// to the iframe by setting its src to ".../App.html#/<inner>".
// When the iframe navigates internally, we listen for postMessage
// from the inner app (sent by the suite-bridge script we inject)
// and reflect the suite hash so deep-links survive refresh.

function parseSuiteHash() {
  const raw = (window.location.hash || "").replace(/^#\//, "");
  if (!raw) return { app: "overview", inner: "" };
  const slash = raw.indexOf("/");
  if (slash === -1) return { app: raw, inner: "" };
  return { app: raw.slice(0, slash), inner: raw.slice(slash + 1) };
}

function setSuiteHash(app, inner) {
  const next = inner ? `#/${app}/${inner}` : `#/${app}`;
  if (window.location.hash !== next) window.location.hash = next;
}

// =============================================================
// Nav definition
// =============================================================

const NAV = [
  {
    section: "Per-job",
    tag: "Solo",
    app: "per-job",
    items: [
      { id: "library",  label: "Library",      glyph: "▤", inner: "library", count: 7 },
      { id: "editor",   label: "Editor",       glyph: "≡", inner: "editor/r_stripe" },
      { id: "diff",     label: "Diff viewer",  glyph: "⇄", inner: "diff" },
      { id: "tailor",   label: "Tailor to JD", glyph: "→", inner: "tailor" },
      { id: "history",  label: "History",      glyph: "◷", inner: "history" },
      { id: "jds",      label: "Job posts",    glyph: "▢", inner: "jds", count: 12 },
      { id: "overflow", label: "Overflow",     glyph: "!", inner: "editor/r_linear" },
    ],
  },
  {
    section: "Mass-apply",
    tag: "Auto",
    app: "mass-apply",
    items: [
      { id: "dashboard", label: "Dashboard", glyph: "◐", inner: "dashboard" },
      { id: "inbox",     label: "Inbox",     glyph: "✉", inner: "inbox", count: 23 },
      { id: "queue",     label: "Queue",     glyph: "⏵", inner: "queue", count: 8 },
      { id: "ma-history",label: "History",   glyph: "◷", inner: "history" },
      { id: "knowledge", label: "Knowledge", glyph: "◇", inner: "knowledge" },
      { id: "tiers",     label: "Tiers",     glyph: "▦", inner: "tiers" },
      { id: "ma-settings", label: "Mass settings", glyph: "✱", inner: "settings" },
    ],
  },
];

const APP_FILE = {
  "per-job": "HireScript.html",
  "mass-apply": "Mass Apply.html",
};

const APP_LABEL = {
  "per-job": "Per-job",
  "mass-apply": "Mass-apply",
  "overview": "Overview",
  "proposal": "Proposal",
};

// =============================================================
// Suite shell
// =============================================================

function SuiteShell() {
  const [route, setRoute] = useState(parseSuiteHash());
  const [cmdOpen, setCmdOpen] = useState(false);
  const [dark, setDark] = useState(false);

  // mounted-once iframes; we don't unmount them on nav so state survives
  const [mountedApps, setMountedApps] = useState(() => new Set([route.app]));
  const iframes = useRef({});

  useEffect(() => {
    const onHash = () => {
      const r = parseSuiteHash();
      setRoute(r);
      setMountedApps((s) => {
        if (s.has(r.app)) return s;
        const next = new Set(s); next.add(r.app); return next;
      });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  // When inner app changes, push the inner hash into the corresponding iframe
  useEffect(() => {
    const f = iframes.current[route.app];
    if (!f || !f.contentWindow) return;
    const targetHash = "#/" + (route.inner || "");
    try {
      const cur = (f.contentWindow.location.hash || "");
      if (cur !== targetHash && targetHash !== "#/") {
        f.contentWindow.location.hash = targetHash;
      }
    } catch (e) { /* cross-origin ignored — same-origin in our case */ }
  }, [route]);

  // Listen for inner-app navigation
  useEffect(() => {
    const onMsg = (ev) => {
      const d = ev.data;
      if (!d || typeof d !== "object") return;
      if (d.type === "suite-inner-hash") {
        const app = d.app;
        const inner = (d.hash || "").replace(/^#\//, "");
        const cur = parseSuiteHash();
        if (cur.app === app && cur.inner !== inner) {
          setSuiteHash(app, inner);
        }
      } else if (d.type === "suite-open") {
        setSuiteHash(d.app, d.inner || "");
      }
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  // ⌘K
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmdOpen((v) => !v);
      } else if (e.key === "Escape") {
        setCmdOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    // Propagate theme to mounted inner apps
    Object.values(iframes.current).forEach((f) => {
      if (!f || !f.contentWindow || !f.contentDocument) return;
      try {
        f.contentDocument.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
        f.contentWindow.postMessage({ type: "suite-theme", dark }, "*");
      } catch (_) {}
    });
  }, [dark]);

  const navigate = useCallback((app, inner = "") => {
    setMountedApps((s) => {
      if (s.has(app)) return s;
      const n = new Set(s); n.add(app); return n;
    });
    setSuiteHash(app, inner);
  }, []);

  return (
    <div className="suite-shell">
      <SuiteTopBar
        route={route}
        onOpenCmd={() => setCmdOpen(true)}
        onToggleDark={() => setDark((d) => !d)}
        dark={dark}
      />
      <SuiteNav route={route} onNavigate={navigate} />
      <main className="suite-main">
        <SuiteContextStrip route={route} />
        <div className="suite-frame-wrap">
          {route.app === "overview" && (
            <SuiteOverview onOpen={navigate} />
          )}
          {Array.from(mountedApps).map((app) => {
            if (app === "overview") return null;
            const file = APP_FILE[app] || (app === "proposal" ? "Proposal.html" : null);
            if (!file) return null;
            const isActive = route.app === app;
            const initialInner = isActive && route.inner ? "#/" + route.inner : "";
            return (
              <iframe
                key={app}
                ref={(el) => { iframes.current[app] = el; }}
                title={APP_LABEL[app] || app}
                src={file + initialInner}
                className={"suite-frame" + (isActive ? " active" : "")}
                onLoad={(e) => {
                  // Inject bridge so the inner app reports hash changes upward
                  try {
                    const w = e.target.contentWindow;
                    const d = e.target.contentDocument;
                    if (!w) return;
                    // Apply current theme to the iframe doc
                    if (d) d.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
                    if (w.__suiteBridgeInstalled) return;
                    w.__suiteBridgeInstalled = true;
                    const send = () => {
                      try {
                        window.postMessage({
                          type: "suite-inner-hash",
                          app,
                          hash: w.location.hash || "#/",
                        }, "*");
                      } catch (_) {}
                    };
                    w.addEventListener("hashchange", send);
                    send();
                  } catch (_) {}
                }}
              />
            );
          })}
        </div>
      </main>
      {cmdOpen && (
        <SuiteCmd
          onClose={() => setCmdOpen(false)}
          onNavigate={(app, inner) => { setCmdOpen(false); navigate(app, inner); }}
          onToggleDark={() => { setDark((d) => !d); setCmdOpen(false); }}
        />
      )}
    </div>
  );
}

// =============================================================
// Top bar
// =============================================================

function SuiteTopBar({ route, onOpenCmd, onToggleDark, dark }) {
  return (
    <header className="suite-top">
      <a className="suite-brand" href="#/" onClick={(e) => { e.preventDefault(); window.location.hash = "#/"; }}>
        <div className="suite-brand-mark">H</div>
        <div>
          <div className="suite-brand-text">HireScript</div>
          <div className="suite-brand-mode">SUITE · v0.4</div>
        </div>
      </a>

      <button className="suite-search" onClick={onOpenCmd} aria-label="Open command palette">
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 11 }}>⌘K</span>
        <span>Search resumes, jobs, screens, commands…</span>
      </button>

      <div className="suite-top-actions">
        <button className="suite-icon-btn" onClick={onToggleDark} title="Toggle theme">
          {dark ? "☼ Light" : "☽ Dark"}
        </button>
        <button className="suite-icon-btn" onClick={() => window.postMessage({ type: "suite-open", app: "proposal" }, "*")} title="Design proposal">
          ✎ Proposal
        </button>
        <div className="suite-avatar">JL</div>
      </div>
    </header>
  );
}

// =============================================================
// Left nav
// =============================================================

function SuiteNav({ route, onNavigate }) {
  return (
    <nav className="suite-nav">
      {NAV.map((sec, i) => (
        <div key={sec.section}>
          <div className="suite-nav-section">
            {sec.section}
            <span className="suite-nav-section-tag">{sec.tag}</span>
          </div>
          {sec.items.map((it) => {
            const active = route.app === sec.app && (
              route.inner === it.inner ||
              route.inner.startsWith(it.inner.split("/")[0] + "/") ||
              (it.inner === "library" && route.inner === "")
            );
            return (
              <button
                key={it.id}
                className={"suite-nav-item" + (active ? " active" : "")}
                onClick={() => onNavigate(sec.app, it.inner)}
              >
                <span className="suite-nav-glyph">{it.glyph}</span>
                <span>{it.label}</span>
                {it.count != null && <span className="suite-nav-count">{it.count}</span>}
              </button>
            );
          })}
          {i < NAV.length - 1 && <div className="suite-nav-divider" />}
        </div>
      ))}

      <div className="suite-nav-divider" />
      <button
        className={"suite-nav-item" + (route.app === "overview" ? " active" : "")}
        onClick={() => onNavigate("overview", "")}
      >
        <span className="suite-nav-glyph">◉</span>
        <span>Overview</span>
      </button>
      <button
        className={"suite-nav-item" + (route.app === "proposal" ? " active" : "")}
        onClick={() => onNavigate("proposal", "")}
      >
        <span className="suite-nav-glyph">✎</span>
        <span>Design proposal</span>
      </button>

      <div className="suite-nav-footer">
        Single user · jamie@<br/>
        Last sync 2m ago<br/>
        Build f3a91c · Apr 26
      </div>
    </nav>
  );
}

// =============================================================
// Context strip
// =============================================================

function SuiteContextStrip({ route }) {
  if (route.app === "overview") {
    return (
      <div className="suite-context">
        <span className="suite-context-tag">Overview</span>
        <span className="suite-context-arrow">›</span>
        <span>Suite home</span>
      </div>
    );
  }
  if (route.app === "proposal") {
    return (
      <div className="suite-context">
        <span className="suite-context-tag">Doc</span>
        <span className="suite-context-arrow">›</span>
        <span>Mass Apply design proposal</span>
      </div>
    );
  }
  const sec = NAV.find((s) => s.app === route.app);
  const item = sec?.items.find((i) => i.inner === route.inner) ||
               sec?.items.find((i) => route.inner.startsWith(i.inner.split("/")[0] + "/")) ||
               sec?.items.find((i) => i.inner === "library");
  const tagClass = route.app === "per-job" ? "per-job" : "mass-apply";
  return (
    <div className="suite-context">
      <span className={"suite-context-tag " + tagClass}>{sec?.section || route.app}</span>
      <span className="suite-context-arrow">›</span>
      <span>{item?.label || route.inner || "—"}</span>
      <span className="suite-context-arrow" style={{ marginLeft: "auto" }}>
        Inner route <span style={{ color: "var(--ink-2)" }}>#/{route.inner || ""}</span>
      </span>
    </div>
  );
}

// =============================================================
// Overview pane
// =============================================================

function SuiteOverview({ onOpen }) {
  return (
    <div className="suite-overview">
      <div className="eyebrow">HireScript Suite · single-user job application toolkit</div>
      <h1>One workspace.<br/>Two ways to apply.</h1>
      <p className="lede">
        HireScript is the careful side: edit one resume against one JD, see the diff, ship a tailored PDF.
        Mass Apply is the volume side: the agent reads JDs from your inbox, applies tier rules, and submits
        in your voice — you supervise.
      </p>

      <div className="twocol">
        <div className="col">
          <span className="col-tag per-job">Per-job</span>
          <h2>HireScript</h2>
          <div className="tagline">
            LaTeX-aware resume editor. You bring the JD, it produces a one-pager you'd actually send.
          </div>
          <ul>
            <li>Library of 7 base resumes, version pinning</li>
            <li>Side-by-side LaTeX diff with protected-term gates</li>
            <li>Page-count guard — every screen turns red at 1.04</li>
            <li>JD library with tailor history per posting</li>
          </ul>
          <button className="open-btn" onClick={() => onOpen("per-job", "library")}>
            Open Library →
          </button>
        </div>

        <div className="col">
          <span className="col-tag mass-apply">Mass-apply</span>
          <h2>Mass Apply</h2>
          <div className="tagline">
            Agent triages new JDs in your inbox, classifies them by tier, and submits inside the headroom you set.
          </div>
          <ul>
            <li>Tier system: dream / targeted / wide / skip</li>
            <li>Knowledge base + sources you've authored</li>
            <li>Submission queue with per-app headroom budget</li>
            <li>11 application states tracked end-to-end</li>
          </ul>
          <button className="open-btn" onClick={() => onOpen("mass-apply", "dashboard")}>
            Open Dashboard →
          </button>
        </div>
      </div>

      <div className="footnote">
        The two apps are intentionally separate surfaces — they share the same identity, the same
        knowledge base, and the same notification stream, but the per-job side is hand-driven and the
        mass-apply side is agent-driven. Press <span className="mono">⌘K</span> to jump anywhere.
        Routes are deep-linkable: <span className="mono">#/per-job/diff</span>,
        <span className="mono"> #/mass-apply/queue</span>, etc.
      </div>
    </div>
  );
}

// =============================================================
// Command palette
// =============================================================

function SuiteCmd({ onClose, onNavigate, onToggleDark }) {
  const [q, setQ] = useState("");
  const inputRef = useRef(null);
  useEffect(() => { inputRef.current?.focus(); }, []);

  const all = useMemo(() => {
    const out = [];
    NAV.forEach((sec) => {
      sec.items.forEach((it) => {
        out.push({
          group: sec.section,
          label: it.label,
          tag: sec.section === "Per-job" ? "per-job" : "mass-apply",
          run: () => onNavigate(sec.app, it.inner),
        });
      });
    });
    out.push({ group: "Suite", label: "Overview",         tag: "suite", run: () => onNavigate("overview", "") });
    out.push({ group: "Suite", label: "Design proposal",  tag: "doc",   run: () => onNavigate("proposal", "") });
    out.push({ group: "Suite", label: "Toggle dark mode", tag: "view",  run: onToggleDark });
    return out;
  }, [onNavigate, onToggleDark]);

  const filtered = useMemo(() => {
    if (!q.trim()) return all;
    const needle = q.toLowerCase();
    return all.filter((c) => c.label.toLowerCase().includes(needle) || c.group.toLowerCase().includes(needle));
  }, [all, q]);

  const grouped = useMemo(() => {
    const m = new Map();
    filtered.forEach((c) => {
      if (!m.has(c.group)) m.set(c.group, []);
      m.get(c.group).push(c);
    });
    return Array.from(m.entries());
  }, [filtered]);

  return (
    <div className="suite-cmd-backdrop" onClick={onClose}>
      <div className="suite-cmd" onClick={(e) => e.stopPropagation()}>
        <div className="suite-cmd-input">
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-3)" }}>⌘K</span>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Jump to a screen, run a command…"
            onKeyDown={(e) => {
              if (e.key === "Enter" && filtered[0]) { filtered[0].run(); }
            }}
          />
          <span className="suite-kbd">esc</span>
        </div>
        <div className="suite-cmd-list">
          {grouped.length === 0 && (
            <div style={{ padding: "20px 18px", color: "var(--ink-3)", fontSize: 13 }}>
              No matches.
            </div>
          )}
          {grouped.map(([group, items]) => (
            <div key={group}>
              <div className="suite-cmd-group">{group}</div>
              {items.map((c, i) => (
                <button key={i} className="suite-cmd-item" onClick={c.run}>
                  <span className="suite-cmd-tag">{c.tag}</span>
                  <span>{c.label}</span>
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// =============================================================
// Mount
// =============================================================

const root = ReactDOM.createRoot(document.getElementById("suite-root"));
root.render(<SuiteShell />);
