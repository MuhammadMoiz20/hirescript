// HireScript mass-apply — fixtures
// Plausible single-user data for Moiz: jobs across all 11 statuses, all 4 tiers,
// 6 ATS sources, applications history, profile, KB sources, tiers config, notifications.

const COMPANIES = {
  anthropic:   { name: "Anthropic",     mark: "A", markBg: "oklch(0.6 0.18 30)" },
  stripe:      { name: "Stripe",        mark: "S", markBg: "oklch(0.55 0.2 295)" },
  linear:      { name: "Linear",        mark: "L", markBg: "oklch(0.4 0.05 270)" },
  ramp:        { name: "Ramp",          mark: "R", markBg: "oklch(0.55 0.18 145)" },
  vercel:      { name: "Vercel",        mark: "V", markBg: "oklch(0.2 0.005 250)" },
  notion:      { name: "Notion",        mark: "N", markBg: "oklch(0.96 0 0)", markFg: "oklch(0.18 0 0)" },
  figma:       { name: "Figma",         mark: "F", markBg: "oklch(0.7 0.18 30)" },
  airtable:    { name: "Airtable",      mark: "A", markBg: "oklch(0.65 0.18 28)" },
  brex:        { name: "Brex",          mark: "B", markBg: "oklch(0.18 0 0)" },
  retool:      { name: "Retool",        mark: "R", markBg: "oklch(0.55 0.18 25)" },
  scale:       { name: "Scale",         mark: "S", markBg: "oklch(0.7 0.16 90)" },
  perplexity:  { name: "Perplexity",    mark: "P", markBg: "oklch(0.55 0.13 200)" },
  arc:         { name: "Arc",           mark: "◐", markBg: "oklch(0.65 0.18 350)" },
  databricks:  { name: "Databricks",    mark: "D", markBg: "oklch(0.55 0.2 25)" },
  snowflake:   { name: "Snowflake",     mark: "❄", markBg: "oklch(0.6 0.15 220)" },
  hashicorp:   { name: "HashiCorp",     mark: "H", markBg: "oklch(0.5 0.2 280)" },
  doordash:    { name: "DoorDash",      mark: "D", markBg: "oklch(0.65 0.2 25)" },
  reddit:      { name: "Reddit",        mark: "R", markBg: "oklch(0.65 0.2 30)" },
  duolingo:    { name: "Duolingo",      mark: "🦉", markBg: "oklch(0.7 0.18 145)" },
  zapier:      { name: "Zapier",        mark: "Z", markBg: "oklch(0.65 0.2 40)" },
  intercom:    { name: "Intercom",      mark: "I", markBg: "oklch(0.4 0.05 250)" },
};

// helper: minutes-ago / hours-ago formatter for fixed reference time
const NOW = new Date("2026-04-26T15:38:00Z");
const ago = (mins) => new Date(NOW.getTime() - mins * 60000).toISOString();

// ─── Jobs across the funnel ─────────────────────────────────────────────────
const JOBS = [
  // Dream tier
  {
    id: "j_001", company: "anthropic", title: "Member of Technical Staff, Inference",
    location: "San Francisco, CA", remote: "hybrid", salary: "$340k–$520k + equity",
    tier: "dream", fitScore: 94, mode: "B", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/anthropic/jobs/4001",
    status: "queued", postedDays: 2, ingestedAt: ago(45),
    fitReason: "Strong match on inference systems experience, CUDA, distributed training. Profile has 4y at NVIDIA + paper on quantization. Salary aligned with target.",
  },
  {
    id: "j_002", company: "stripe", title: "Staff Engineer, Money Movement",
    location: "Remote, US", remote: "remote", salary: "$310k–$420k",
    tier: "dream", fitScore: 91, mode: "A", modeOverride: true,
    source: "ashby", sourceUrl: "https://jobs.ashbyhq.com/stripe/staff-mm",
    status: "applying", postedDays: 1, ingestedAt: ago(180),
    fitReason: "Payments ledger experience at NVIDIA's billing infra. Listed protected terms (idempotent, exactly-once, p99) all present in master. Stage: tailoring resume.",
  },
  {
    id: "j_003", company: "perplexity", title: "Founding Engineer, Search Infra",
    location: "San Francisco, CA", remote: "onsite", salary: "$280k–$400k + 0.3-0.8% equity",
    tier: "dream", fitScore: 88, mode: "B", modeOverride: false,
    source: "lever", sourceUrl: "https://jobs.lever.co/perplexity/search-infra",
    status: "needs_attention", postedDays: 4, ingestedAt: ago(2400),
    fitReason: "Distributed search + LLM retrieval. Verifier flagged: claim 'led 12-person team' not supported by KB — manager confirms 8 reports.",
  },

  // Targeted tier
  {
    id: "j_004", company: "linear", title: "Staff Product Engineer",
    location: "San Francisco / Remote", remote: "hybrid", salary: "$240k–$310k",
    tier: "targeted", fitScore: 82, mode: "B", modeOverride: false,
    source: "ashby", sourceUrl: "https://jobs.ashbyhq.com/linear/staff-product",
    status: "applied", postedDays: 6, ingestedAt: ago(8400),
    fitReason: "Frontend depth + sync engine background. Linear values taste highly; portfolio aligns.",
  },
  {
    id: "j_005", company: "ramp", title: "Senior Engineer, Platform",
    location: "New York, NY", remote: "hybrid", salary: "$220k–$290k",
    tier: "targeted", fitScore: 78, mode: "A", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/ramp/jobs/5012",
    status: "applied", postedDays: 3, ingestedAt: ago(3600),
    fitReason: "Backend + infra strong. Compensation range slightly below target.",
  },
  {
    id: "j_006", company: "vercel", title: "Senior Software Engineer, Edge",
    location: "Remote", remote: "remote", salary: "$220k–$300k",
    tier: "targeted", fitScore: 81, mode: "B", modeOverride: true,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/vercel/jobs/4910",
    status: "queued", postedDays: 1, ingestedAt: ago(120),
    fitReason: "Edge runtime + Next.js core. Strong on profile, untested company match.",
  },
  {
    id: "j_007", company: "figma", title: "Senior Backend Engineer, Realtime",
    location: "San Francisco, CA", remote: "hybrid", salary: "$240k–$320k",
    tier: "targeted", fitScore: 76, mode: "A", modeOverride: false,
    source: "ashby", sourceUrl: "https://jobs.ashbyhq.com/figma/realtime",
    status: "paused", postedDays: 5, ingestedAt: ago(1100),
    fitReason: "Realtime infra match. Paused on captcha at submit step.",
  },
  {
    id: "j_008", company: "airtable", title: "Staff Engineer, Sync",
    location: "San Francisco, CA", remote: "hybrid", salary: "$260k–$330k",
    tier: "targeted", fitScore: 74, mode: "A", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/airtable/jobs/3300",
    status: "stuck", postedDays: 7, ingestedAt: ago(7200),
    fitReason: "Sync engine, CRDT background. Agent stuck on 'Years of relevant experience' field — no profile mapping.",
  },

  // Wide-net tier
  {
    id: "j_009", company: "brex", title: "Software Engineer III",
    location: "Remote, US", remote: "remote", salary: "$180k–$240k",
    tier: "wide_net", fitScore: 64, mode: "A", modeOverride: false,
    source: "lever", sourceUrl: "https://jobs.lever.co/brex/eng3",
    status: "applied", postedDays: 2, ingestedAt: ago(960),
  },
  {
    id: "j_010", company: "retool", title: "Backend Engineer",
    location: "San Francisco, CA", remote: "hybrid", salary: "$170k–$220k",
    tier: "wide_net", fitScore: 58, mode: "A", modeOverride: false,
    source: "ashby", sourceUrl: "https://jobs.ashbyhq.com/retool/backend",
    status: "classified", postedDays: 1, ingestedAt: ago(15),
  },
  {
    id: "j_011", company: "scale", title: "Senior ML Engineer",
    location: "San Francisco, CA", remote: "onsite", salary: "$200k–$280k",
    tier: "wide_net", fitScore: 62, mode: "A", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/scale/jobs/2100",
    status: "ingested", postedDays: 1, ingestedAt: ago(8),
  },
  {
    id: "j_012", company: "databricks", title: "Senior Software Engineer, Storage",
    location: "Mountain View, CA", remote: "hybrid", salary: "$210k–$290k",
    tier: "wide_net", fitScore: 67, mode: "A", modeOverride: false,
    source: "workable", sourceUrl: "https://databricks.workable.com/jobs/storage",
    status: "applying", postedDays: 3, ingestedAt: ago(24),
  },
  {
    id: "j_013", company: "snowflake", title: "Software Engineer III",
    location: "San Mateo, CA", remote: "hybrid", salary: "$190k–$250k",
    tier: "wide_net", fitScore: 55, mode: "A", modeOverride: false,
    source: "url_paste", sourceUrl: "https://snowflake.com/careers/12345",
    status: "skipped", postedDays: 8, ingestedAt: ago(11000),
  },
  {
    id: "j_014", company: "hashicorp", title: "Senior Engineer, Terraform Cloud",
    location: "Remote", remote: "remote", salary: "$190k–$250k",
    tier: "wide_net", fitScore: 60, mode: "A", modeOverride: false,
    source: "lever", sourceUrl: "https://jobs.lever.co/hashicorp/tfc",
    status: "snoozed", postedDays: 4, ingestedAt: ago(3000), snoozeUntil: ago(-2880),
  },
  {
    id: "j_015", company: "doordash", title: "Software Engineer, Logistics",
    location: "San Francisco, CA", remote: "hybrid", salary: "$175k–$235k",
    tier: "wide_net", fitScore: 52, mode: "A", modeOverride: false,
    source: "agentic", sourceUrl: "https://doordash.com/careers/logistics",
    status: "errored", postedDays: 5, ingestedAt: ago(2200),
  },
  {
    id: "j_016", company: "reddit", title: "Senior Backend Engineer",
    location: "Remote, US", remote: "remote", salary: "$200k–$270k",
    tier: "wide_net", fitScore: 70, mode: "A", modeOverride: false,
    source: "email", sourceUrl: "mailto:digest",
    status: "queued", postedDays: 2, ingestedAt: ago(440),
  },
  {
    id: "j_017", company: "duolingo", title: "Backend Engineer (Curriculum)",
    location: "Pittsburgh, PA", remote: "hybrid", salary: "$180k–$240k",
    tier: "wide_net", fitScore: 49, mode: "A", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/duolingo/jobs/1100",
    status: "skipped", postedDays: 6, ingestedAt: ago(5400),
  },

  // Skip tier
  {
    id: "j_018", company: "zapier", title: "Software Engineer (Generalist)",
    location: "Remote", remote: "remote", salary: "$140k–$180k",
    tier: "skip", fitScore: 38, mode: "A", modeOverride: false,
    source: "ashby", sourceUrl: "https://jobs.ashbyhq.com/zapier/swe",
    status: "skipped", postedDays: 9, ingestedAt: ago(13000),
  },
  {
    id: "j_019", company: "intercom", title: "Junior Frontend Engineer",
    location: "Dublin, IE", remote: "hybrid", salary: "€55k–€72k",
    tier: "skip", fitScore: 22, mode: "A", modeOverride: false,
    source: "greenhouse", sourceUrl: "https://job-boards.greenhouse.io/intercom/jobs/8100",
    status: "skipped", postedDays: 2, ingestedAt: ago(900),
  },
];

// ─── Applications history (read-only) ───────────────────────────────────────
const APPLICATIONS = [
  { id: "a_01", jobId: "j_004", appliedAt: ago(120),  mode: "B", confirmation: "Linear-2026-04-26-cf42.html", tokensIn: 42100, tokensOut: 1840, wallS: 11.4, sentResume: true, sentCover: true, sentAnswers: true },
  { id: "a_02", jobId: "j_005", appliedAt: ago(60),   mode: "A", confirmation: "Ramp-2026-04-26-bf12.html",   tokensIn: 38400, tokensOut: 1620, wallS: 9.8, sentResume: true, sentCover: true, sentAnswers: false },
  { id: "a_03", jobId: "j_009", appliedAt: ago(840),  mode: "A", confirmation: "Brex-2026-04-26-aa31.html",   tokensIn: 31200, tokensOut: 1240, wallS: 8.1, sentResume: true, sentCover: false, sentAnswers: true },
  { id: "a_04", jobId: "j_010", appliedAt: ago(2400), mode: "A", confirmation: "Retool-2026-04-25-9911.html", tokensIn: 33800, tokensOut: 1380, wallS: 8.9, sentResume: true, sentCover: false, sentAnswers: true },
  { id: "a_05", jobId: "j_011", appliedAt: ago(2520), mode: "A", confirmation: "Scale-2026-04-25-7720.html",  tokensIn: 35100, tokensOut: 1450, wallS: 9.5, sentResume: true, sentCover: true, sentAnswers: true },
  { id: "a_06", jobId: "j_012", appliedAt: ago(4200), mode: "A", confirmation: "Databricks-2026-04-25-5512.html", tokensIn: 41200, tokensOut: 1700, wallS: 10.6, sentResume: true, sentCover: true, sentAnswers: true },
  { id: "a_07", jobId: "j_006", appliedAt: ago(4800), mode: "B", confirmation: "Vercel-2026-04-25-3344.html",  tokensIn: 39800, tokensOut: 1560, wallS: 10.1, sentResume: true, sentCover: true, sentAnswers: false },
  { id: "a_08", jobId: "j_007", appliedAt: ago(5600), mode: "A", confirmation: "Figma-2026-04-25-2211.html",   tokensIn: 36500, tokensOut: 1490, wallS: 9.2, sentResume: true, sentCover: false, sentAnswers: true },
  { id: "a_09", jobId: "j_008", appliedAt: ago(8800), mode: "A", confirmation: "Airtable-2026-04-25-1010.html", tokensIn: 32400, tokensOut: 1310, wallS: 8.5, sentResume: true, sentCover: false, sentAnswers: true },
  { id: "a_10", jobId: "j_009", appliedAt: ago(10100), mode: "A", confirmation: "Brex-2026-04-25-0044.html",   tokensIn: 30100, tokensOut: 1180, wallS: 7.8, sentResume: true, sentCover: false, sentAnswers: true },
  { id: "a_11", jobId: "j_011", appliedAt: ago(11500), mode: "A", confirmation: "Scale-2026-04-25-9912.html",  tokensIn: 34000, tokensOut: 1390, wallS: 8.7, sentResume: true, sentCover: true, sentAnswers: false },
  { id: "a_12", jobId: "j_010", appliedAt: ago(13200), mode: "A", confirmation: "Retool-2026-04-25-7711.html", tokensIn: 32100, tokensOut: 1240, wallS: 8.0, sentResume: true, sentCover: false, sentAnswers: true },
];

// ─── Activity feed events (last ~24h) ───────────────────────────────────────
const ACTIVITY = [
  { at: ago(2),    type: "applied",    company: "ramp",        body: "Ramp — Senior Engineer, Platform · A-mode · Greenhouse" },
  { at: ago(8),    type: "applying",   company: "stripe",      body: "Stripe — Staff, Money Movement · tailoring resume (iter 2)" },
  { at: ago(11),   type: "ingested",   company: "scale",       body: "Scale — Senior ML Engineer ingested via Greenhouse poll" },
  { at: ago(15),   type: "classified", company: "retool",      body: "Retool — Backend Engineer · wide_net · fit 58/100" },
  { at: ago(22),   type: "stuck",      company: "airtable",    body: "Airtable agent stuck on \"Years of relevant experience\" — needs answer" },
  { at: ago(34),   type: "paused",     company: "figma",       body: "Figma submission paused — captcha · tap to finish (90s)" },
  { at: ago(45),   type: "applied",    company: "brex",        body: "Brex — Software Engineer III · A-mode · Lever" },
  { at: ago(60),   type: "ingested",   company: "vercel",      body: "Vercel — Senior Engineer, Edge · queued for tailor" },
  { at: ago(78),   type: "applied",    company: "linear",      body: "Linear — Staff Product Engineer · B-mode reviewed + sent" },
  { at: ago(95),   type: "errored",    company: "doordash",    body: "DoorDash adapter failed (selector timeout) — promoted to agent" },
  { at: ago(120),  type: "applied",    company: "retool",      body: "Retool — Backend Engineer · A-mode · Ashby" },
  { at: ago(140),  type: "applied",    company: "scale",       body: "Scale — Senior ML Engineer · A-mode · Greenhouse" },
  { at: ago(165),  type: "needs_attention", company: "perplexity", body: "Perplexity — verifier blocked unsupported claim · review" },
  { at: ago(180),  type: "research",   company: "anthropic",   body: "Anthropic dream-tier brief generated · 12 sources, 4.2k tokens" },
  { at: ago(220),  type: "applied",    company: "databricks",  body: "Databricks — Storage · A-mode · Workable" },
  { at: ago(280),  type: "applied",    company: "vercel",      body: "Vercel — Edge · B-mode · Greenhouse" },
  { at: ago(360),  type: "applied",    company: "figma",       body: "Figma — Realtime · A-mode · Ashby (after captcha resume)" },
  { at: ago(420),  type: "ingested",   company: "reddit",      body: "Reddit — Senior Backend · via email digest" },
  { at: ago(540),  type: "skipped",    company: "duolingo",    body: "Duolingo — Curriculum · skipped, fit 49 < wide_net floor" },
  { at: ago(680),  type: "applied",    company: "airtable",    body: "Airtable — Sync · A-mode (recovered after agent fallback)" },
];

// ─── Profile (Moiz) ─────────────────────────────────────────────────────────
const PROFILE = {
  legal_name: "Moiz Khan",
  preferred_name: "Moiz",
  email: "moiz@khan.dev",
  phone: "+1 (415) 555-0188",
  address: "1284 Folsom St, San Francisco, CA 94103",
  pronouns: "he/him",
  timezone: "America/Los_Angeles",
  links: {
    linkedin: "linkedin.com/in/moizkhan",
    github: "github.com/moiz",
    site: "moiz.dev",
    x: "@moizk",
  },
  work_auth: {
    citizenships: ["United States", "Pakistan"],
    sponsorship: { US: false, UK: true, EU: true, CA: false, AU: true },
    relocate_to: ["NYC", "Seattle", "Remote-US"],
  },
  positions: [
    { company: "NVIDIA", title: "Senior Software Engineer, Inference", start: "2022-08", end: null, location: "Santa Clara, CA", type: "full_time", blurb: "Lead on quantization runtime for Llama-class models. Owns CUDA kernel perf for two product lines." },
    { company: "Stripe", title: "Software Engineer, Payments Infra", start: "2019-06", end: "2022-07", location: "San Francisco, CA", type: "full_time", blurb: "Ledger and money-movement perf. Reduced settlement p99 from 3.2s to 410ms." },
    { company: "Two Sigma", title: "Software Engineer, Trading Infra", start: "2017-07", end: "2019-05", location: "New York, NY", type: "full_time", blurb: "Real-time risk pipeline; 30 → 8 ms tail latency." },
  ],
  education: [
    { institution: "Carnegie Mellon University", degree: "B.S.", field: "Computer Science", start: "2013-09", end: "2017-05" },
  ],
  certs: ["AWS Certified Solutions Architect (2023)"],
  languages: ["English (native)", "Urdu (native)", "Spanish (conversational)"],
  preferences: {
    salary_floor_usd: 260000,
    salary_target_usd: 320000,
    role_families: ["Staff/Senior IC", "Inference systems", "Distributed systems", "Payments infra"],
    dealbreakers: ["RTO 5 days", "Defense contracts", "On-call > 1 week / 6 weeks"],
    company_stages: ["series_b_plus", "public", "series_a"],
    work_modes: ["remote", "hybrid"],
    cover_letter_default: true,
    disclose_salary_default: false,
  },
  eeo: {
    gender: "Man",
    race_ethnicity: "Asian",
    veteran: "Not a protected veteran",
    disability: "Prefer not to say",
  },
  kill_list: [
    { company: "Palantir", reason: "Defense work" },
    { company: "Meta", reason: "Previous bad interview" },
    { company: "ByteDance", reason: "Conflict (held equity)" },
  ],
};

// ─── KB sources ─────────────────────────────────────────────────────────────
const KB_SOURCES = [
  { id: "latex_master", name: "Master LaTeX", status: "connected",      lastSync: ago(180),    docs: 1,  chunks: 14, configurable: false },
  { id: "markdown",     name: "Manual Markdown", status: "connected",   lastSync: ago(60),     docs: 12, chunks: 64, configurable: false },
  { id: "notion",       name: "Notion",          status: "connected",   lastSync: ago(380),    docs: 38, chunks: 142, configurable: true,
    config: { dbs: ["Career notes", "Project journal", "Interview prep"], lastScan: ago(380) } },
  { id: "website",      name: "Personal Website", status: "connected",  lastSync: ago(1080),   docs: 22, chunks: 88, configurable: true,
    config: { baseUrl: "https://moiz.dev", allow: ["/blog/*", "/projects/*"], deny: ["/private/*", "/drafts/*"] } },
  { id: "github",       name: "GitHub READMEs",   status: "error",      lastSync: ago(2400),   docs: 7,  chunks: 31, configurable: true,
    config: { repos: ["moiz/cudakit", "moiz/leakwatch", "moiz/refold"], readmeOnly: true },
    error: "Rate limited (5000/h budget exhausted) — retries in 22m" },
  { id: "onboarding",   name: "Onboarding notes", status: "connected",  lastSync: ago(120),    docs: 6,  chunks: 11, configurable: false },
];

// KB documents (subset, for explorer)
const KB_DOCS = [
  { id: "d1", source: "latex_master", title: "Master Resume — Moiz Khan",         fetchedAt: ago(180),  chunks: 14 },
  { id: "d2", source: "markdown",     title: "Quantization war stories",          fetchedAt: ago(60),   chunks: 8 },
  { id: "d3", source: "markdown",     title: "Stripe ledger — postmortem notes",  fetchedAt: ago(60),   chunks: 6 },
  { id: "d4", source: "notion",       title: "Career notes / Why I left Stripe",  fetchedAt: ago(380),  chunks: 4 },
  { id: "d5", source: "notion",       title: "Project journal / cudakit kernel",  fetchedAt: ago(380),  chunks: 12 },
  { id: "d6", source: "notion",       title: "Interview prep / system design",    fetchedAt: ago(380),  chunks: 22 },
  { id: "d7", source: "website",      title: "Blog: \"Why p99 is the only number that matters\"", fetchedAt: ago(1080), chunks: 5 },
  { id: "d8", source: "website",      title: "Project: cudakit",                  fetchedAt: ago(1080), chunks: 7 },
  { id: "d9", source: "github",       title: "moiz/cudakit · README",             fetchedAt: ago(2400), chunks: 6 },
  { id: "d10", source: "onboarding",  title: "Q: How many direct reports at NVIDIA?", fetchedAt: ago(120), chunks: 1 },
];

// Sample retrieval result for the live KB query box
const KB_RETRIEVAL_SAMPLE = {
  query: "ledger idempotency exactly-once payments",
  results: [
    { docId: "d3", title: "Stripe ledger — postmortem notes", source: "markdown", distance: 0.142, snippet: "…the double-charge bug came from a non-idempotent retry inside the ledger's settlement loop. We added a (request_id, ledger_account) unique constraint and switched to exactly-once via Kafka transactions…" },
    { docId: "d1", title: "Master Resume — Moiz Khan", source: "latex_master", distance: 0.218, snippet: "Led migration of the payments ledger from Postgres to a sharded CockroachDB cluster, cutting p99 write latency from 140ms to 38ms." },
    { docId: "d4", title: "Career notes / Why I left Stripe", source: "notion", distance: 0.331, snippet: "The team had grown to 28 and the ledger was bottlenecking on settlement coordination. We tried two-phase commit before exactly-once …" },
    { docId: "d8", title: "Project: cudakit", source: "website", distance: 0.466, snippet: "Not strictly a payments project, but the same idempotency lessons applied: every cudakit kernel commit takes a deterministic seed so reruns produce identical PRNG state." },
  ],
};

// ─── Tiers config ───────────────────────────────────────────────────────────
const TIERS = [
  {
    id: "dream", label: "Dream", fitMin: 85, fitMax: 100,
    defaultMode: "B", dailyCap: 3, dailyUsed: 1,
    models: { classify: "haiku", research: "opus", tailor: "opus", cover: "sonnet" },
    research: "full", coverRequired: true, verifier: "strict",
    examples: ["Anthropic — Inference", "Stripe — Staff MM"],
  },
  {
    id: "targeted", label: "Targeted", fitMin: 60, fitMax: 84,
    defaultMode: "A", dailyCap: 15, dailyUsed: 7,
    models: { classify: "haiku", research: "sonnet", tailor: "sonnet", cover: "sonnet" },
    research: "brief", coverRequired: true, verifier: "strict",
    examples: ["Linear — Staff Product Eng", "Vercel — Edge"],
  },
  {
    id: "wide_net", label: "Wide net", fitMin: 40, fitMax: 59,
    defaultMode: "A", dailyCap: 30, dailyUsed: 18,
    models: { classify: "haiku", research: "off", tailor: "haiku", cover: "haiku" },
    research: "off", coverRequired: false, verifier: "lenient",
    examples: ["Brex — SE III", "Retool — Backend"],
  },
  {
    id: "skip", label: "Skip", fitMin: 0, fitMax: 39,
    defaultMode: "A", dailyCap: 0, dailyUsed: 0,
    models: { classify: "haiku", research: "off", tailor: "off", cover: "off" },
    research: "off", coverRequired: false, verifier: "n/a",
    examples: ["Zapier — Generalist", "Intercom — Junior FE"],
  },
];

// ─── Sources config ─────────────────────────────────────────────────────────
const SOURCES_CONFIG = [
  {
    family: "ats", label: "ATS direct", tos: "clean", tosNote: "Public job-board APIs and listings",
    items: [
      { provider: "greenhouse", boards: 24, lastPoll: ago(8),  jobs24h: 142, errors24h: 0, cadence: 15 },
      { provider: "lever",      boards: 18, lastPoll: ago(12), jobs24h: 88,  errors24h: 0, cadence: 15 },
      { provider: "ashby",      boards: 31, lastPoll: ago(6),  jobs24h: 102, errors24h: 1, cadence: 15 },
      { provider: "workable",   boards: 9,  lastPoll: ago(14), jobs24h: 24,  errors24h: 0, cadence: 15 },
    ],
  },
  {
    family: "aggregator", label: "Aggregator APIs", tos: "clean", tosNote: "Per provider terms; rate-limited",
    items: [
      { provider: "Adzuna",     enabled: true,  apiKeySet: true,  jobs24h: 64 },
      { provider: "Reed",       enabled: false, apiKeySet: false, jobs24h: 0 },
    ],
  },
  {
    family: "scraping", label: "Scraping (LinkedIn / Indeed / Wellfound)", tos: "red",
    tosNote: "Against ToS. Feature-flagged. We handle backoff but you accept the risk.",
    items: [
      { provider: "LinkedIn",   enabled: false, riskAck: false },
      { provider: "Indeed",     enabled: false, riskAck: false },
      { provider: "Wellfound",  enabled: true,  riskAck: true, jobs24h: 11 },
    ],
  },
  {
    family: "email", label: "Email digest", tos: "clean",
    tosNote: "IMAP read-only of labelled inbox folders",
    items: [
      { provider: "moiz@khan.dev", labels: ["jobs/", "linkedin/saved"], imap: "imap.fastmail.com:993", auth: "OK", jobs24h: 7 },
    ],
  },
  {
    family: "url_paste", label: "URL paste", tos: "clean", tosNote: "One-page scrape; nothing automated",
    items: [],
  },
  {
    family: "agentic", label: "Agentic discovery", tos: "grey",
    tosNote: "Claude searches public web; respects robots.txt; daily token budget",
    items: [
      { tokensPerDay: 200000, tokensUsedToday: 84000, regions: ["US", "Remote-US", "EU"], seed: "Senior/staff IC roles in inference, distributed systems, payments infra at Series B+ companies. Avoid agency/recruiting firms." },
    ],
  },
];

// ─── Notifications ──────────────────────────────────────────────────────────
const NOTIFICATIONS = [
  { id: "n1", at: ago(22),   type: "captcha",   read: false, title: "Stripe is asking for a captcha", body: "Tap to finish — pipeline pauses in 90s",            link: "/queue#j_007" },
  { id: "n2", at: ago(35),   type: "stuck",     read: false, title: "Airtable agent stuck",          body: "Field unmapped: 'Years of relevant experience'",     link: "/queue#j_008" },
  { id: "n3", at: ago(165),  type: "review",    read: false, title: "Perplexity — review needed",    body: "Verifier blocked claim; team-size mismatch",         link: "/queue#j_003" },
  { id: "n4", at: ago(440),  type: "review",    read: true,  title: "Vercel — review ready",         body: "B-mode resume + cover letter ready to send",         link: "/queue#j_006" },
  { id: "n5", at: ago(720),  type: "summary",   read: true,  title: "Daily summary",                 body: "12 applied · 3 in queue · 1 stuck",                  link: "/dashboard" },
  { id: "n6", at: ago(1440), type: "source",    read: true,  title: "GitHub poll failing",           body: "Rate limited; retries in ~22m",                      link: "/knowledge/sources" },
  { id: "n7", at: ago(2400), type: "applied",   read: true,  title: "Applied to Linear",             body: "Staff Product Engineer · B-mode · Greenhouse",       link: "/history#a_01" },
];

// ─── Live browser session (mock) ────────────────────────────────────────────
const LIVE_SESSION = {
  jobId: "j_008",
  agentSteps: [
    { idx: 1, at: ago(8),   step: "Navigated to greenhouse.io/airtable/jobs/3300/apply",                  shot: "step1",  outcome: "ok" },
    { idx: 2, at: ago(7),   step: "Filled 'Full name' = 'Moiz Khan'",                                     shot: "step2",  outcome: "ok" },
    { idx: 3, at: ago(7),   step: "Filled 'Email' = 'moiz@khan.dev'",                                     shot: "step3",  outcome: "ok" },
    { idx: 4, at: ago(6),   step: "Uploaded resume: Airtable — Sync_v1.pdf",                              shot: "step4",  outcome: "ok" },
    { idx: 5, at: ago(5),   step: "Filled 'Years of experience' = '8'",                                   shot: "step5",  outcome: "ok" },
    { idx: 6, at: ago(4),   step: "Filled cover letter (1840 chars)",                                      shot: "step6",  outcome: "ok" },
    { idx: 7, at: ago(3),   step: "Set 'Authorized to work in US?' = 'Yes'",                              shot: "step7",  outcome: "ok" },
    { idx: 8, at: ago(2),   step: "Encountered 'Years of relevant CRDT experience' — no profile mapping", shot: "step8",  outcome: "stuck" },
    { idx: 9, at: ago(1),   step: "Asking user: please answer the field highlighted in the viewport",    shot: "step9",  outcome: "wait" },
  ],
};

// ─── Counters ───────────────────────────────────────────────────────────────
const COUNTERS = {
  applied24h: 12,
  applied7d:  87,
  applied30d: 312,
  ingested24h: 248,
  classified24h: 248,
  tailored24h: 22,
  inQueue: 4,
  stuck: 1,
  errored24h: 1,
  paused: 1,
  // tier breakdown (today)
  byTier: { dream: { used: 1, cap: 3 }, targeted: { used: 7, cap: 15 }, wide_net: { used: 18, cap: 30 } },
  byMode: { A: 9, B: 3 },
  // Max-window
  maxWindow: { pctUsed: 62, resetsInMin: 107, maxLimitTokens: 5_000_000, usedTokens: 3_100_000 },
  // 14-day applied sparkline
  sparkApplied: [5, 8, 11, 9, 14, 12, 15, 10, 13, 17, 9, 12, 14, 12],
};

window.MA = {
  COMPANIES, JOBS, APPLICATIONS, ACTIVITY, PROFILE, KB_SOURCES, KB_DOCS,
  KB_RETRIEVAL_SAMPLE, TIERS, SOURCES_CONFIG, NOTIFICATIONS, LIVE_SESSION, COUNTERS,
  NOW,
  fmtAgo: (iso) => {
    const ms = NOW.getTime() - new Date(iso).getTime();
    const m = Math.round(ms / 60000);
    if (m < 1) return "now";
    if (m < 60) return `${m}m`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h}h`;
    const d = Math.round(h / 24);
    return `${d}d`;
  },
  fmtAgoLong: (iso) => {
    const ms = NOW.getTime() - new Date(iso).getTime();
    const m = Math.round(ms / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m} min ago`;
    const h = Math.floor(m / 60);
    const rm = m % 60;
    if (h < 24) return rm ? `${h}h ${rm}m ago` : `${h}h ago`;
    const d = Math.round(h / 24);
    return `${d}d ago`;
  },
  // Find a job by id, with company expansion
  job: (id) => {
    const j = JOBS.find(x => x.id === id);
    if (!j) return null;
    return { ...j, _company: COMPANIES[j.company] };
  },
};
