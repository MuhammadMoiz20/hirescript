// Dashboard, Inbox, Queue, History (with detail), Live session viewer.

const { useState: useS1, useEffect: useE1, useMemo: useM1 } = React;

// ─── DASHBOARD ──────────────────────────────────────────────────────────────
function Dashboard({ onOpenJob }) {
  const c = window.MA.COUNTERS;
  const activity = window.MA.ACTIVITY;
  return (
    <div>
      <PageHeader
        eyebrow="Dashboard"
        title="Today, at a glance"
        sub="Your hiring agent is awake. Twelve applications submitted in the last 24 hours, one stuck, one paused for review."
        right={
          <div style={{ display: "flex", gap: 10 }}>
            <Btn kind="default" size="md">⏸ Pause all</Btn>
            <Btn kind="primary" size="md">+ Add job by URL</Btn>
          </div>
        }
      />

      {/* KPI band */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", padding: "24px 40px", gap: 24, borderBottom: "1px solid var(--rule)" }}>
        <Card>
          <Eyebrow>Applied · last 14 days</Eyebrow>
          <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginTop: 6 }}>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 36, fontWeight: 600, color: "var(--ink)" }}>{c.applied30d}</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>this period</div>
          </div>
          <div style={{ marginTop: 8 }}>
            <Sparkline values={c.sparkApplied} w={300} h={36} stroke="var(--ink)" fill />
          </div>
        </Card>
        <Card>
          <Eyebrow>Queue</Eyebrow>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 6 }}>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 36, fontWeight: 600, color: "var(--ink)" }}>{c.inQueue}</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>in flight</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 10, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
            <div><span style={{ color: "var(--haiku)" }}>◆</span> Queued · 1</div>
            <div><span style={{ color: "var(--sonnet)" }}>▶</span> Applying · 2</div>
            <div><span style={{ color: "var(--warn)" }}>‖</span> Paused · 1</div>
          </div>
        </Card>
        <Card>
          <Eyebrow>Needs you</Eyebrow>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 6 }}>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 36, fontWeight: 600, color: "var(--accent)" }}>{c.stuck + 1}</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>blockers</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 10, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
            <div><span style={{ color: "var(--accent)" }}>✕</span> Stuck · {c.stuck}</div>
            <div><span style={{ color: "var(--err)" }}>!</span> Review · 1</div>
          </div>
        </Card>
        <Card>
          <Eyebrow>Max-window</Eyebrow>
          <div style={{ marginTop: 4, display: "flex", alignItems: "center", gap: 14 }}>
            <MaxGauge pct={c.maxWindow.pctUsed} size={72} showLabel={false} />
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", lineHeight: 1.6 }}>
              <div><span style={{ color: "var(--ink)", fontWeight: 600 }}>3.1M</span> / 5M tok</div>
              <div>resets 1h 47m</div>
              <div>~ 6 dream apps left</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Tier capacity + by-mode */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", padding: "24px 40px", gap: 32, borderBottom: "1px solid var(--rule)" }}>
        <div>
          <Eyebrow>Daily caps · by tier</Eyebrow>
          <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 12 }}>
            <CapBar tier="dream"    used={c.byTier.dream.used}    cap={c.byTier.dream.cap}    label="Dream" />
            <CapBar tier="targeted" used={c.byTier.targeted.used} cap={c.byTier.targeted.cap} label="Targeted" />
            <CapBar tier="wide_net" used={c.byTier.wide_net.used} cap={c.byTier.wide_net.cap} label="Wide net" />
          </div>
        </div>
        <div>
          <Eyebrow>Mode mix · today</Eyebrow>
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 24 }}>
            <div style={{ display: "flex", alignItems: "stretch", height: 36, width: 280, border: "1px solid var(--rule)" }}>
              <div style={{ flex: c.byMode.A, background: "var(--ink)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--paper)", fontFamily: "var(--f-mono)", fontSize: 11 }}>
                ⚡ A · {c.byMode.A}
              </div>
              <div style={{ flex: c.byMode.B, background: "var(--paper-3)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--ink)", fontFamily: "var(--f-mono)", fontSize: 11 }}>
                ◉ B · {c.byMode.B}
              </div>
            </div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", lineHeight: 1.6 }}>
              <div><span style={{ color: "var(--ink)", fontWeight: 600 }}>{Math.round((c.byMode.A / (c.byMode.A + c.byMode.B)) * 100)}%</span> autonomous</div>
              <div>{c.byMode.B} reviewed by you</div>
            </div>
          </div>
        </div>
      </div>

      {/* Two-column: Needs you + Activity */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
        <div style={{ borderRight: "1px solid var(--rule)" }}>
          <Section title="Needs you" sub="Resolve these before the agent stalls" style={{ borderBottom: "none" }}>
            <NeedsYouRow job={window.MA.job("j_008")} reason="Field unmapped: 'Years of relevant CRDT experience'" cta="Answer" onClick={() => onOpenJob("j_008")} />
            <NeedsYouRow job={window.MA.job("j_007")} reason="Captcha — 90s window before pipeline drops" cta="Solve" onClick={() => onOpenJob("j_007")} />
            <NeedsYouRow job={window.MA.job("j_003")} reason="Verifier blocked — claim not supported by KB" cta="Review" onClick={() => onOpenJob("j_003")} />
            <NeedsYouRow job={window.MA.job("j_006")} reason="B-mode review ready" cta="Review" onClick={() => onOpenJob("j_006")} />
          </Section>
        </div>
        <div>
          <Section title="Activity feed" sub="Last 12 hours · live" style={{ borderBottom: "none" }}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              {activity.slice(0, 11).map((a, i) => (
                <ActivityRow key={i} item={a} />
              ))}
            </div>
            <div style={{ marginTop: 10 }}>
              <Btn kind="ghost" size="sm">View full history →</Btn>
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}

function NeedsYouRow({ job, reason, cta, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "12px 0", borderBottom: "1px solid var(--rule)",
      cursor: "pointer",
    }}>
      <CompanyMark company={job.company} size={28} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontWeight: 500, color: "var(--ink)" }}>{job._company.name}</span>
          <TierBadge tier={job.tier} />
        </div>
        <div style={{ fontSize: 12, color: "var(--ink-2)", marginTop: 2 }}>{job.title}</div>
        <div style={{ fontSize: 11, color: "var(--accent)", marginTop: 4, fontFamily: "var(--f-mono)" }}>↳ {reason}</div>
      </div>
      <Btn kind="primary" size="sm">{cta} →</Btn>
    </div>
  );
}

function ActivityRow({ item }) {
  const c = window.MA.COMPANIES[item.company];
  const meta = STATUS_META[item.type] || { glyph: "·", color: "ink-3", label: item.type };
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid var(--rule)" }}>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--ink-4)", width: 32 }}>{window.MA.fmtAgo(item.at)}</span>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: `var(--${meta.color})`, width: 14, textAlign: "center" }}>{meta.glyph}</span>
      <CompanyMark company={item.company} size={16} />
      <span style={{ fontSize: 12, color: "var(--ink-2)", flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.body}</span>
    </div>
  );
}

// ─── INBOX ──────────────────────────────────────────────────────────────────
function Inbox({ onOpenJob }) {
  const [filter, setFilter] = useS1("all");
  const [tier, setTier] = useS1("all");
  const jobs = useM1(() => {
    return window.MA.JOBS.filter(j => {
      if (filter === "needs" && !["needs_attention", "stuck", "paused"].includes(j.status)) return false;
      if (filter === "applied" && j.status !== "applied") return false;
      if (filter === "queued" && !["queued", "classified", "ingested", "applying"].includes(j.status)) return false;
      if (tier !== "all" && j.tier !== tier) return false;
      return true;
    }).sort((a, b) => new Date(b.ingestedAt) - new Date(a.ingestedAt));
  }, [filter, tier]);

  return (
    <div>
      <PageHeader
        eyebrow="Inbox"
        title="Every job, ever"
        sub="One unified table. Filter, sort, override mode, snooze, kill."
        right={
          <div style={{ display: "flex", gap: 8 }}>
            <Btn kind="default" size="md">⌕ Save filter</Btn>
            <Btn kind="primary" size="md">+ Add by URL</Btn>
          </div>
        }
      />

      {/* Filter bar */}
      <div style={{ padding: "16px 40px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <FilterChips value={filter} onChange={setFilter} options={[
          { id: "all", label: "All", count: window.MA.JOBS.length },
          { id: "needs", label: "Needs you", count: 4, accent: true },
          { id: "queued", label: "In queue", count: 6 },
          { id: "applied", label: "Applied", count: 4 },
        ]} />
        <Hr vertical style={{ height: 18 }} />
        <FilterChips value={tier} onChange={setTier} options={[
          { id: "all", label: "Any tier" },
          { id: "dream", label: "Dream" },
          { id: "targeted", label: "Targeted" },
          { id: "wide_net", label: "Wide net" },
          { id: "skip", label: "Skip" },
        ]} />
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>
          <span>{jobs.length} of {window.MA.JOBS.length}</span>
          <span>·</span>
          <span>Sorted by ingested ↓</span>
        </div>
      </div>

      {/* Table */}
      <div style={{ padding: "0 40px" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: "1px solid var(--rule)" }}>
              <Th w={28} />
              <Th>Company / Role</Th>
              <Th w={86}>Tier</Th>
              <Th w={70}>Fit</Th>
              <Th w={130}>Status</Th>
              <Th w={68}>Mode</Th>
              <Th w={120}>Source</Th>
              <Th w={70}>Ingested</Th>
              <Th w={28} />
            </tr>
          </thead>
          <tbody>
            {jobs.map(j => <JobRow key={j.id} job={window.MA.job(j.id)} onOpen={() => onOpenJob(j.id)} />)}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({ children, w }) {
  return <th style={{
    textAlign: "left", padding: "10px 8px",
    fontFamily: "var(--f-mono)", fontSize: 10, fontWeight: 500,
    color: "var(--ink-4)", letterSpacing: "0.06em", textTransform: "uppercase",
    width: w, whiteSpace: "nowrap",
  }}>{children}</th>;
}
function Td({ children, style: s, ...rest }) {
  return <td {...rest} style={{ padding: "10px 8px", verticalAlign: "middle", ...s }}>{children}</td>;
}

function JobRow({ job, onOpen }) {
  return (
    <tr onClick={onOpen} style={{ borderBottom: "1px solid var(--rule)", cursor: "pointer" }}
      onMouseEnter={e => e.currentTarget.style.background = "var(--paper-2)"}
      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
      <Td><CompanyMark company={job.company} size={22} /></Td>
      <Td>
        <div style={{ fontWeight: 500, color: "var(--ink)" }}>{job._company.name}</div>
        <div style={{ fontSize: 11, color: "var(--ink-3)" }}>{job.title}</div>
      </Td>
      <Td><TierBadge tier={job.tier} /></Td>
      <Td><FitChip score={job.fitScore} /></Td>
      <Td><StatusPill status={job.status} /></Td>
      <Td><ModeToggle value={job.mode} overridden={job.modeOverride} interactive={false} /></Td>
      <Td><SourceTag source={job.source} /></Td>
      <Td><span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>{window.MA.fmtAgo(job.ingestedAt)}</span></Td>
      <Td><span style={{ color: "var(--ink-4)", fontFamily: "var(--f-mono)" }}>›</span></Td>
    </tr>
  );
}

function FilterChips({ value, onChange, options }) {
  return (
    <div style={{ display: "inline-flex", gap: 6, flexWrap: "wrap" }}>
      {options.map(o => {
        const active = value === o.id;
        return (
          <button key={o.id} onClick={() => onChange(o.id)} style={{
            padding: "4px 10px",
            background: active ? "var(--ink)" : "transparent",
            color: active ? "var(--paper)" : (o.accent ? "var(--accent)" : "var(--ink-2)"),
            border: `1px solid ${active ? "var(--ink)" : (o.accent ? "var(--accent)" : "var(--rule)")}`,
            fontFamily: "var(--f-sans)", fontSize: 12,
            cursor: "pointer", borderRadius: 2,
            display: "inline-flex", alignItems: "center", gap: 5,
          }}>
            {o.label}
            {o.count != null && <span className="mono" style={{ fontSize: 10, opacity: 0.7 }}>{o.count}</span>}
          </button>
        );
      })}
    </div>
  );
}

// ─── JOB DETAIL DRAWER ──────────────────────────────────────────────────────
function JobDrawer({ jobId, onClose }) {
  if (!jobId) return null;
  const j = window.MA.job(jobId);
  if (!j) return null;
  return (
    <>
      <div onClick={onClose} style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.18)", zIndex: 100,
      }} />
      <aside style={{
        position: "fixed", top: 0, right: 0, bottom: 0,
        width: 720, maxWidth: "100vw",
        background: "var(--paper)", borderLeft: "1px solid var(--rule)",
        zIndex: 101,
        display: "flex", flexDirection: "column",
        overflowY: "auto",
      }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "flex-start", gap: 14 }}>
          <CompanyMark company={j.company} size={40} />
          <div style={{ flex: 1 }}>
            <div className="serif" style={{ fontSize: 22, color: "var(--ink)" }}>{j._company.name}</div>
            <div style={{ fontSize: 14, color: "var(--ink-2)", marginTop: 2 }}>{j.title}</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", marginTop: 6 }}>
              {j.location} · {j.remote} · {j.salary}
            </div>
          </div>
          <button onClick={onClose} style={{
            background: "transparent", border: "1px solid var(--rule)",
            color: "var(--ink-2)", fontFamily: "var(--f-mono)", fontSize: 14,
            width: 28, height: 28, cursor: "pointer",
          }}>×</button>
        </div>

        {/* Status strip */}
        <div style={{ padding: "14px 24px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <StatusPill status={j.status} size="lg" />
          <TierBadge tier={j.tier} size="lg" />
          <FitChip score={j.fitScore} size="lg" />
          <ModeToggle value={j.mode} overridden={j.modeOverride} size="lg" />
          <SourceTag source={j.source} />
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>ingested {window.MA.fmtAgoLong(j.ingestedAt)}</span>
        </div>

        {/* Why this tier */}
        {j.fitReason && (
          <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--rule)" }}>
            <Eyebrow>Why · classifier</Eyebrow>
            <div style={{ fontSize: 13, color: "var(--ink-2)", marginTop: 6, lineHeight: 1.6 }}>{j.fitReason}</div>
          </div>
        )}

        {/* Pipeline trace */}
        <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--rule)" }}>
          <Eyebrow>Pipeline trace</Eyebrow>
          <div style={{ marginTop: 10 }}>
            <PipelineTrace job={j} />
          </div>
        </div>

        {/* Artifacts */}
        <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--rule)" }}>
          <Eyebrow>Artifacts</Eyebrow>
          <div style={{ display: "flex", gap: 14, marginTop: 12 }}>
            <PdfThumb name={`${j._company.name} — Resume`} w={120} h={160} pageCount={1} />
            <div style={{ flex: 1, fontSize: 12, color: "var(--ink-2)", lineHeight: 1.7 }}>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid var(--rule)" }}>
                <span style={{ color: "var(--ink-3)" }}>Resume</span>
                <span className="mono" style={{ fontSize: 11 }}>{j._company.name.replace(/\s+/g, "_")}_v1.pdf</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid var(--rule)" }}>
                <span style={{ color: "var(--ink-3)" }}>Cover letter</span>
                <span className="mono" style={{ fontSize: 11 }}>{j.tier === "wide_net" ? "—" : "cover_v1.pdf"}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid var(--rule)" }}>
                <span style={{ color: "var(--ink-3)" }}>Diff</span>
                <Btn kind="ghost" size="sm">View diff →</Btn>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid var(--rule)" }}>
                <span style={{ color: "var(--ink-3)" }}>Sources cited</span>
                <span className="mono" style={{ fontSize: 11, color: "var(--ink-2)" }}>12 chunks · 4 docs</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ padding: "16px 24px", display: "flex", gap: 8, flexWrap: "wrap" }}>
          {j.status === "needs_attention" || j.status === "stuck" || j.status === "paused" ? (
            <Btn kind="primary" size="md">Resolve →</Btn>
          ) : null}
          {j.status === "queued" || j.status === "classified" ? (
            <Btn kind="primary" size="md">Apply now</Btn>
          ) : null}
          <Btn kind="default" size="md">Override mode</Btn>
          <Btn kind="default" size="md">Re-classify</Btn>
          <Btn kind="default" size="md">Snooze 3d</Btn>
          <Btn kind="danger" size="md">Skip · add to kill list</Btn>
        </div>
      </aside>
    </>
  );
}

function PipelineTrace({ job }) {
  // Always show 4 stages; mark progress.
  const stages = [
    { id: "ingest",   label: "Ingest",     model: null,            done: true, t: window.MA.fmtAgo(job.ingestedAt) },
    { id: "classify", label: "Classify",   model: "haiku",         done: ["queued","applying","applied","needs_attention","stuck","paused","skipped","errored"].includes(job.status), t: "+0.4s" },
    { id: "tailor",   label: "Tailor",     model: job.tier === "dream" ? "opus" : job.tier === "targeted" ? "sonnet" : "haiku", done: ["applying","applied","needs_attention","stuck","paused"].includes(job.status), t: job.tier === "dream" ? "+18s" : "+9s" },
    { id: "submit",   label: "Submit",     model: null,            done: job.status === "applied", t: job.status === "applied" ? "+11s" : null, current: ["applying","stuck","paused","needs_attention"].includes(job.status) },
  ];
  return (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0 }}>
      {stages.map((s, i) => (
        <React.Fragment key={s.id}>
          <div style={{
            flex: 1, padding: "10px 12px",
            background: s.done ? "var(--paper-2)" : (s.current ? "var(--warn-soft)" : "var(--paper)"),
            border: "1px solid var(--rule)",
            borderRight: i < stages.length - 1 ? "none" : "1px solid var(--rule)",
            position: "relative",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: s.done ? "var(--ok)" : (s.current ? "var(--warn)" : "var(--ink-4)") }}>
                {s.done ? "✓" : (s.current ? "▶" : "○")}
              </span>
              <span style={{ fontSize: 12, color: "var(--ink)", fontWeight: 500 }}>{s.label}</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
              {s.model && <ModelBadge model={s.model} />}
              {s.t && <span className="mono" style={{ fontSize: 10, color: "var(--ink-3)" }}>{s.t}</span>}
            </div>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── QUEUE (B-mode review center) ───────────────────────────────────────────
function Queue({ onOpenJob }) {
  // 4 lanes: Needs you, B-mode review, Applying live, Paused
  const needsYou = window.MA.JOBS.filter(j => ["stuck","needs_attention","paused"].includes(j.status));
  const bReview  = window.MA.JOBS.filter(j => j.mode === "B" && j.status === "queued");
  const applying = window.MA.JOBS.filter(j => j.status === "applying");
  const paused   = window.MA.JOBS.filter(j => j.status === "paused");
  return (
    <div>
      <PageHeader
        eyebrow="Queue"
        title="The agent's working surface"
        sub="What's in flight, what needs you, and what's waiting on review."
      />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", borderBottom: "1px solid var(--rule)" }}>
        <Lane title="Needs you"     accent="accent" jobs={needsYou} onOpenJob={onOpenJob} hint="Solve before agent stalls" />
        <Lane title="B-mode review" accent="ink"    jobs={bReview}  onOpenJob={onOpenJob} hint="Resume + cover ready" />
        <Lane title="Applying"      accent="sonnet" jobs={applying} onOpenJob={onOpenJob} hint="Live agent steps" />
        <Lane title="Paused"        accent="warn"   jobs={paused}   onOpenJob={onOpenJob} hint="Captcha · 2FA · Other" />
      </div>

      {/* Live session viewer */}
      <Section title="Live · Stripe Money Movement" sub="A-mode agent on greenhouse.io · step 9 of estimated 14" right={<><Btn kind="default" size="sm">Pause</Btn><Btn kind="danger" size="sm" style={{ marginLeft: 8 }}>Stop</Btn></>}>
        <LiveSessionViewer />
      </Section>
    </div>
  );
}

function Lane({ title, accent, jobs, onOpenJob, hint }) {
  return (
    <div style={{ borderRight: "1px solid var(--rule)", display: "flex", flexDirection: "column", minHeight: 380 }}>
      <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid var(--rule)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 6, height: 6, borderRadius: 6, background: `var(--${accent})` }} />
          <div style={{ fontSize: 13, color: "var(--ink)", fontWeight: 600 }}>{title}</div>
          <span className="mono" style={{ marginLeft: "auto", fontSize: 11, color: "var(--ink-4)" }}>{jobs.length}</span>
        </div>
        <div style={{ fontSize: 11, color: "var(--ink-4)", marginTop: 2 }}>{hint}</div>
      </div>
      <div style={{ flex: 1, padding: 10, display: "flex", flexDirection: "column", gap: 8 }}>
        {jobs.length === 0 ? (
          <div style={{ flex: 1, display: "grid", placeItems: "center", color: "var(--ink-4)", fontFamily: "var(--f-mono)", fontSize: 11 }}>nothing here</div>
        ) : (
          jobs.map(j => <LaneCard key={j.id} job={window.MA.job(j.id)} accent={accent} onClick={() => onOpenJob(j.id)} />)
        )}
      </div>
    </div>
  );
}

function LaneCard({ job, accent, onClick }) {
  const blockerByStatus = {
    stuck: "Field unmapped",
    needs_attention: "Verifier flagged claim",
    paused: "Captcha · 90s",
  };
  return (
    <div onClick={onClick} style={{
      padding: 10, background: "var(--paper)", border: "1px solid var(--rule)",
      cursor: "pointer", display: "flex", flexDirection: "column", gap: 8,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <CompanyMark company={job.company} size={20} />
        <div style={{ fontSize: 12, color: "var(--ink)", fontWeight: 500, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{job._company.name}</div>
        <TierBadge tier={job.tier} />
      </div>
      <div style={{ fontSize: 11, color: "var(--ink-3)", lineHeight: 1.4 }}>{job.title}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "space-between" }}>
        <ModeToggle value={job.mode} overridden={job.modeOverride} interactive={false} />
        {blockerByStatus[job.status] && (
          <span className="mono" style={{ fontSize: 10, color: `var(--${accent})` }}>↳ {blockerByStatus[job.status]}</span>
        )}
      </div>
    </div>
  );
}

function LiveSessionViewer() {
  const session = window.MA.LIVE_SESSION;
  const job = window.MA.job(session.jobId);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, alignItems: "stretch" }}>
      {/* Browser preview */}
      <div style={{
        background: "var(--paper)", border: "1px solid var(--rule)",
        boxShadow: "0 0 0 1px var(--live-frame), 0 0 0 4px var(--live-frame-soft)",
        animation: "pulse-frame 2.4s ease-in-out infinite",
      }}>
        <div style={{ padding: "8px 12px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 8, background: "var(--paper-2)" }}>
          <span style={{ display: "flex", gap: 5 }}>
            <span style={{ width: 9, height: 9, borderRadius: 9, background: "oklch(0.7 0.2 25)" }} />
            <span style={{ width: 9, height: 9, borderRadius: 9, background: "oklch(0.85 0.15 90)" }} />
            <span style={{ width: 9, height: 9, borderRadius: 9, background: "oklch(0.75 0.2 145)" }} />
          </span>
          <div style={{ flex: 1, padding: "3px 10px", background: "var(--paper)", border: "1px solid var(--rule)", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            🔒 boards.greenhouse.io/airtable/jobs/3300/applications/new
          </div>
          <span className="mono" style={{ fontSize: 10, color: "var(--accent)" }}>● LIVE</span>
        </div>
        <div style={{ padding: 18, fontFamily: "var(--f-sans)", color: "var(--ink-2)", fontSize: 12, lineHeight: 1.6, position: "relative", minHeight: 320 }}>
          <div className="serif" style={{ fontSize: 18, color: "var(--ink)", marginBottom: 4 }}>Apply — Staff Engineer, Sync</div>
          <div style={{ fontSize: 11, color: "var(--ink-3)", marginBottom: 16 }}>Airtable · San Francisco / Hybrid</div>

          <FormRow label="Full name" value="Moiz Khan" filled />
          <FormRow label="Email" value="moiz@khan.dev" filled />
          <FormRow label="Resume" value="Airtable — Sync_v1.pdf · 1 page · uploaded" filled />
          <FormRow label="Years of experience" value="8" filled />
          <FormRow label="Cover letter" value="… 1840 chars" filled />
          <FormRow label="Authorized to work in US?" value="Yes" filled />
          <FormRow label="Years of relevant CRDT experience" value="" stuck />
          <FormRow label="LinkedIn URL" value="" pending />
        </div>
      </div>

      {/* Step trace */}
      <div style={{ background: "var(--paper)", border: "1px solid var(--rule)", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 8 }}>
          <ModelBadge model="haiku" />
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>step 9 / ~14 · 2,340 tok</span>
          <span style={{ marginLeft: "auto", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--accent)" }}>WAITING ON YOU</span>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 8 }}>
          {window.MA.LIVE_SESSION.agentSteps.map(s => (
            <div key={s.idx} style={{
              padding: "8px 10px", borderBottom: "1px solid var(--rule)",
              display: "flex", alignItems: "flex-start", gap: 10,
              background: s.outcome === "stuck" || s.outcome === "wait" ? "var(--warn-soft)" : "transparent",
            }}>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--ink-4)", width: 20 }}>{String(s.idx).padStart(2, "0")}</span>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: s.outcome === "ok" ? "var(--ok)" : (s.outcome === "stuck" ? "var(--accent)" : "var(--warn)"), width: 14 }}>
                {s.outcome === "ok" ? "✓" : (s.outcome === "stuck" ? "✕" : "?")}
              </span>
              <div style={{ flex: 1, fontSize: 12, color: "var(--ink-2)", lineHeight: 1.5 }}>{s.step}</div>
            </div>
          ))}
        </div>
        <div style={{ padding: 12, borderTop: "1px solid var(--rule)", background: "var(--paper-2)", display: "flex", gap: 8 }}>
          <Input placeholder="Type your answer (e.g. 4)" style={{ flex: 1 }} />
          <Btn kind="primary" size="md">Send →</Btn>
        </div>
      </div>
    </div>
  );
}

function FormRow({ label, value, filled, stuck, pending }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", marginBottom: 14 }}>
      <label style={{ fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--f-mono)", marginBottom: 4 }}>{label}</label>
      <div style={{
        padding: "5px 10px", minHeight: 26,
        background: stuck ? "var(--accent-soft)" : "var(--paper)",
        border: `1px solid ${stuck ? "var(--accent)" : "var(--rule)"}`,
        color: filled ? "var(--ink)" : "var(--ink-4)",
        fontSize: 12, fontFamily: filled ? "var(--f-sans)" : "var(--f-mono)",
        position: "relative",
      }}>
        {value || (pending ? "…" : <span style={{ color: "var(--accent)", fontStyle: "italic" }}>← agent stopped here, waiting on you</span>)}
        {stuck && <span style={{
          position: "absolute", right: 8, top: 5,
          fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--accent)",
        }}>STUCK</span>}
      </div>
    </div>
  );
}

// ─── HISTORY ────────────────────────────────────────────────────────────────
function History({ onOpenApp }) {
  return (
    <div>
      <PageHeader
        eyebrow="History"
        title="Read-only application archive"
        sub="Every submitted application — what was sent, where, with what model and tokens. Click any row to view the full bundle."
      />
      <div style={{ padding: "16px 40px", borderBottom: "1px solid var(--rule)", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-3)" }}>{window.MA.APPLICATIONS.length} applications · 30 days</span>
        <Hr vertical style={{ height: 14 }} />
        <Sparkline values={window.MA.COUNTERS.sparkApplied} w={200} h={24} stroke="var(--ink-2)" />
        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <Btn kind="ghost" size="sm">Export CSV</Btn>
          <Btn kind="ghost" size="sm">Export bundle (.zip)</Btn>
        </div>
      </div>

      <div style={{ padding: "0 40px" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: "1px solid var(--rule)" }}>
              <Th w={28} />
              <Th>Company / Role</Th>
              <Th w={86}>Tier</Th>
              <Th w={100}>Applied</Th>
              <Th w={68}>Mode</Th>
              <Th w={120}>Sent</Th>
              <Th w={140}>Tokens · wall</Th>
              <Th w={28} />
            </tr>
          </thead>
          <tbody>
            {window.MA.APPLICATIONS.map(a => {
              const j = window.MA.job(a.jobId);
              return (
                <tr key={a.id} onClick={() => onOpenApp(a.id)} style={{ borderBottom: "1px solid var(--rule)", cursor: "pointer" }}
                  onMouseEnter={e => e.currentTarget.style.background = "var(--paper-2)"}
                  onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                  <Td><CompanyMark company={j.company} size={22} /></Td>
                  <Td>
                    <div style={{ fontWeight: 500, color: "var(--ink)" }}>{j._company.name}</div>
                    <div style={{ fontSize: 11, color: "var(--ink-3)" }}>{j.title}</div>
                  </Td>
                  <Td><TierBadge tier={j.tier} /></Td>
                  <Td><span className="mono" style={{ fontSize: 11, color: "var(--ink-2)" }}>{window.MA.fmtAgo(a.appliedAt)} ago</span></Td>
                  <Td><ModeToggle value={a.mode} interactive={false} /></Td>
                  <Td>
                    <div style={{ display: "flex", gap: 5 }}>
                      <SentTick on={a.sentResume} label="R" title="Resume" />
                      <SentTick on={a.sentCover} label="C" title="Cover" />
                      <SentTick on={a.sentAnswers} label="A" title="Answers" />
                    </div>
                  </Td>
                  <Td>
                    <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-2)" }}>
                      {(a.tokensIn / 1000).toFixed(1)}k → {(a.tokensOut / 1000).toFixed(1)}k · {a.wallS.toFixed(1)}s
                    </div>
                  </Td>
                  <Td><span style={{ color: "var(--ink-4)", fontFamily: "var(--f-mono)" }}>›</span></Td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SentTick({ on, label, title }) {
  return (
    <span title={title} style={{
      width: 18, height: 18,
      display: "inline-grid", placeItems: "center",
      fontFamily: "var(--f-mono)", fontSize: 10, fontWeight: 600,
      color: on ? "var(--ok)" : "var(--ink-4)",
      border: `1px solid ${on ? "var(--ok)" : "var(--rule)"}`,
      background: on ? "var(--ok-soft)" : "transparent",
    }}>{label}</span>
  );
}

Object.assign(window, { Dashboard, Inbox, Queue, History, JobDrawer, LiveSessionViewer });
